
import React, { useState, useMemo } from 'react';
import { Booking, Room, Guest, BookingStatus, Payment, PaymentMode, PaymentAccount, PlatformSettings } from '../types';
import { BookingModal } from './BookingModal';

interface BookingWizardModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSaveBooking: (booking: Omit<Booking, 'id'> & { id?: string }) => void;
    onSaveGuest: (guest: Omit<Guest, 'id'>) => Guest;
    guests: Guest[];
    rooms: Room[];
    existingBookings: Booking[];
    propertyId: string;
    paymentModes: PaymentMode[];
    paymentAccounts: PaymentAccount[];
    platformSettings: PlatformSettings;
    propertyManagementType: 'OYO' | 'SELF';
}

export const BookingWizardModal: React.FC<BookingWizardModalProps> = (props) => {
    const { isOpen, onClose, onSaveBooking, onSaveGuest, guests, platformSettings, propertyManagementType } = props;
    const [step, setStep] = useState(1);
    const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);
    
    // State for guest search
    const [guestSearchTerm, setGuestSearchTerm] = useState('');

    // State for new guest form
    const [newGuestData, setNewGuestData] = useState({ name: '', email: '', phone: '' });
    const [isCreatingNewGuest, setIsCreatingNewGuest] = useState(false);


    const filteredGuests = useMemo(() => {
        if (!guestSearchTerm) return [];
        return guests.filter(g => 
            g.name.toLowerCase().includes(guestSearchTerm.toLowerCase()) || 
            g.email.toLowerCase().includes(guestSearchTerm.toLowerCase())
        );
    }, [guestSearchTerm, guests]);

    const handleSelectGuest = (guest: Guest) => {
        setSelectedGuest(guest);
        setStep(2);
    };
    
    const handleCreateNewGuest = (e: React.FormEvent) => {
        e.preventDefault();
        if(newGuestData.name && newGuestData.email) {
            const newlyCreatedGuest = onSaveGuest(newGuestData);
            setSelectedGuest(newlyCreatedGuest);
            setStep(2);
        } else {
            alert('Please provide a name and email for the new guest.');
        }
    };

    const handleSaveFromBookingForm = (bookingToSave: Omit<Booking, 'id'> & { id?: string }) => {
        if (!selectedGuest) {
            alert("Error: No guest selected.");
            return;
        }
        onSaveBooking({ ...bookingToSave, guestId: selectedGuest.id });
        resetAndClose();
    };

    const resetAndClose = () => {
        setStep(1);
        setSelectedGuest(null);
        setGuestSearchTerm('');
        setNewGuestData({ name: '', email: '', phone: '' });
        setIsCreatingNewGuest(false);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-start py-10 overflow-y-auto" onClick={resetAndClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl" onClick={e => e.stopPropagation()}>
                {/* Wizard Header */}
                 <div className="p-6 border-b">
                    <h2 className="text-2xl font-bold text-gray-800">Add New Booking</h2>
                    <div className="mt-2 flex items-center">
                        <div className={`flex items-center ${step >= 1 ? 'text-brand-primary' : 'text-gray-400'}`}>
                            <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold ${step >= 1 ? 'border-brand-primary' : 'border-gray-400'}`}>1</div>
                            <span className="ml-2 font-semibold">Select Guest</span>
                        </div>
                        <div className="flex-grow h-px bg-gray-300 mx-4"></div>
                        <div className={`flex items-center ${step >= 2 ? 'text-brand-primary' : 'text-gray-400'}`}>
                            <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold ${step >= 2 ? 'border-brand-primary' : 'border-gray-400'}`}>2</div>
                            <span className="ml-2 font-semibold">Booking Details</span>
                        </div>
                    </div>
                </div>

                {step === 1 && (
                    <div className="p-8">
                        {/* Guest Search */}
                        <div className="mb-6">
                            <label htmlFor="guestSearch" className="block text-sm font-medium text-gray-700 mb-1">Search for Existing Guest</label>
                            <input
                                id="guestSearch"
                                type="text"
                                placeholder="Start typing name or email..."
                                value={guestSearchTerm}
                                onChange={(e) => setGuestSearchTerm(e.target.value)}
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm"
                            />
                            {guestSearchTerm && (
                                <ul className="mt-2 border border-gray-200 rounded-md max-h-40 overflow-y-auto">
                                    {filteredGuests.length > 0 ? filteredGuests.map(guest => (
                                        <li key={guest.id} onClick={() => handleSelectGuest(guest)} className="px-4 py-2 hover:bg-brand-light cursor-pointer">
                                            {guest.name} <span className="text-gray-500 text-xs">({guest.email})</span>
                                        </li>
                                    )) : <li className="px-4 py-2 text-gray-500">No guests found.</li>}
                                </ul>
                            )}
                        </div>

                        <div className="relative my-6">
                            <div className="absolute inset-0 flex items-center" aria-hidden="true"><div className="w-full border-t border-gray-300" /></div>
                            <div className="relative flex justify-center"><span className="bg-white px-2 text-sm text-gray-500">OR</span></div>
                        </div>

                        {/* New Guest Form */}
                        <div>
                             <button onClick={() => setIsCreatingNewGuest(p => !p)} className="text-brand-primary font-semibold text-sm w-full text-left">
                                {isCreatingNewGuest ? '▼ Hide New Guest Form' : '▶ Create a New Guest'}
                            </button>
                            {isCreatingNewGuest && (
                                <form onSubmit={handleCreateNewGuest} className="mt-4 space-y-3 bg-gray-50 p-4 rounded-lg">
                                    <h3 className="font-semibold">New Guest Details</h3>
                                    <input type="text" placeholder="Full Name" value={newGuestData.name} onChange={e => setNewGuestData(p => ({...p, name: e.target.value}))} className="block w-full rounded-md border-gray-300" required/>
                                    <input type="email" placeholder="Email Address" value={newGuestData.email} onChange={e => setNewGuestData(p => ({...p, email: e.target.value}))} className="block w-full rounded-md border-gray-300" required/>
                                    <input type="tel" placeholder="Phone Number" value={newGuestData.phone} onChange={e => setNewGuestData(p => ({...p, phone: e.target.value}))} className="block w-full rounded-md border-gray-300"/>
                                    <div className="text-right">
                                        <button type="submit" className="bg-brand-secondary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Create Guest & Continue</button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                )}
                
                {step === 2 && selectedGuest && (
                     <BookingModal
                        isOpen={true}
                        onClose={resetAndClose}
                        onSave={handleSaveFromBookingForm}
                        booking={null} // Always creation mode
                        rooms={props.rooms}
                        guests={[selectedGuest]} // Only show the selected guest
                        existingBookings={props.existingBookings}
                        propertyId={props.propertyId}
                        paymentModes={props.paymentModes}
                        paymentAccounts={props.paymentAccounts}
                        platformSettings={platformSettings}
                        propertyManagementType={propertyManagementType}
                    />
                )}

            </div>
        </div>
    );
};