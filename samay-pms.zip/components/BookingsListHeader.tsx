
import React from 'react';

export const BookingsListHeader: React.FC = () => {
    return (
        <div className="bg-gray-50 rounded-lg grid grid-cols-12 items-center text-xs font-semibold text-gray-500 uppercase tracking-wider">
             <div className="col-span-1 p-3">
                <input type="checkbox" className="h-4 w-4 rounded border-gray-300 text-brand-primary focus:ring-brand-primary" />
            </div>
            <div className="col-span-3 p-3">Guest & Room</div>
            <div className="col-span-2 p-3">Dates</div>
            <div className="col-span-2 p-3">Status</div>
            <div className="col-span-2 p-3 text-right">Payment</div>
            <div className="col-span-2 p-3 text-right">Actions</div>
        </div>
    );
};