
import React, { useState } from 'react';
import { Page } from '../types';
import { NAV_ITEMS, NavItem } from '../constants';

interface SidebarProps {
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
}

const ChevronDownIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, setCurrentPage }) => {
    const getParentOfActive = () => {
        const activeParent = NAV_ITEMS.find(item => item.children?.some(child => child.id === currentPage));
        return activeParent ? activeParent.id : null;
    }
    const [openMenu, setOpenMenu] = useState<string | null>(getParentOfActive());


    const handleNavClick = (item: NavItem) => {
        if (item.children) {
            setOpenMenu(openMenu === item.id ? null : item.id);
        } else {
            setCurrentPage(item.id as Page);
        }
    }

    return (
        <aside className="w-64 bg-brand-dark text-white flex flex-col">
            <div className="h-16 flex items-center justify-center border-b border-gray-700">
                <h1 className="text-2xl font-bold tracking-wider">Samay PMS</h1>
            </div>
            <nav className="flex-1 px-4 py-6 space-y-1">
                {NAV_ITEMS.map((item) => {
                    const isParentOfActive = item.children?.some(c => c.id === currentPage) ?? false;
                    const isActive = currentPage === item.id || isParentOfActive;
                    const isMenuOpen = openMenu === item.id;

                    return (
                        <div key={item.id}>
                            <a
                                href="#"
                                onClick={(e) => {
                                    e.preventDefault();
                                    handleNavClick(item);
                                }}
                                className={`flex items-center justify-between px-4 py-3 rounded-lg transition-colors duration-200 ${
                                    isActive ? 'bg-brand-primary text-white' : 'hover:bg-brand-secondary hover:bg-opacity-50'
                                }`}
                            >
                                <div className="flex items-center">
                                    <item.icon className="h-6 w-6 mr-3" />
                                    <span className="font-medium">{item.label}</span>
                                </div>
                                {item.children && (
                                    <ChevronDownIcon className={`h-5 w-5 transition-transform duration-300 ${isMenuOpen ? 'rotate-180' : ''}`} />
                                )}
                            </a>
                            {item.children && isMenuOpen && (
                                <div className="pl-8 pt-1 pb-2 space-y-1">
                                    {item.children.map(child => {
                                         const isChildActive = currentPage === child.id;
                                         return (
                                            <a
                                                key={child.id}
                                                href="#"
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    setCurrentPage(child.id);
                                                }}
                                                className={`block px-4 py-2 rounded-lg text-sm transition-colors duration-200 ${
                                                    isChildActive ? 'bg-brand-secondary text-white font-semibold' : 'text-gray-300 hover:bg-brand-secondary hover:bg-opacity-25'
                                                }`}
                                            >
                                                {child.label}
                                            </a>
                                         );
                                    })}
                                </div>
                            )}
                        </div>
                    );
                })}
            </nav>
            <div className="px-4 py-4 border-t border-gray-700">
                <p className="text-xs text-gray-400">&copy; 2025 Samay PMS. All rights reserved.</p>
            </div>
        </aside>
    );
};
