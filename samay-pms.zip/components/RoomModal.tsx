
import React, { useState, useEffect } from 'react';
import { Room, RoomType, HousekeepingStatus } from '../types';

interface RoomModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (room: Omit<Room, 'id' | 'propertyId' | 'housekeepingStatus'> & { id?: string }) => void;
    onDelete: (roomId: string) => void;
    room: Room | null;
}

const getInitialData = (room: Room | null) => ({
    name: room?.name || '',
    type: room?.type || RoomType.Single,
});

export const RoomModal: React.FC<RoomModalProps> = ({ isOpen, onClose, onSave, onDelete, room }) => {
    const [formData, setFormData] = useState(getInitialData(room));

    useEffect(() => {
        setFormData(getInitialData(room));
    }, [room, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.name) {
            onSave({ id: room?.id, ...formData });
        } else {
            alert('Room name is required.');
        }
    };
    
    const handleDelete = () => {
        if(room && window.confirm(`Are you sure you want to delete ${room.name}? This will also cancel any bookings for this room.`)) {
            onDelete(room.id);
        }
    }

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold text-gray-800">{room ? 'Edit Room' : 'Add New Room'}</h2>
                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700">Room Name/Number</label>
                        <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required />
                    </div>
                    <div>
                        <label htmlFor="type" className="block text-sm font-medium text-gray-700">Room Type</label>
                        <select id="type" name="type" value={formData.type} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required>
                            {Object.values(RoomType).map(type => <option key={type} value={type}>{type}</option>)}
                        </select>
                    </div>
                    
                    <div className="flex justify-between items-center pt-4">
                        <div>
                            {room && (
                                <button type="button" onClick={handleDelete} className="bg-red-100 text-red-700 font-bold py-2 px-4 rounded-lg hover:bg-red-200 transition-colors">Delete</button>
                            )}
                        </div>
                        <div className="flex space-x-3">
                            <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">Cancel</button>
                            <button type="submit" className="bg-brand-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Save Room</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};
