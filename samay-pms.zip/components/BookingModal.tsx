
import React, { useState, useEffect, useMemo } from 'react';
import { Booking, Room, Guest, BookingStatus, Payment, PaymentMode, PaymentAccount, PlatformSettings } from '../types';

interface BookingModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (booking: Omit<Booking, 'id'> & { id?: string }) => void;
    booking: Booking | null;
    rooms: Room[];
    guests: Guest[];
    existingBookings: Booking[];
    propertyId: string;
    paymentModes: PaymentMode[];
    paymentAccounts: PaymentAccount[];
    platformSettings: PlatformSettings;
    propertyManagementType: 'OYO' | 'SELF';
}

const toISODate = (d: Date | string) => new Date(d).toISOString().split('T')[0];
const todayStr = toISODate(new Date());

const getInitialFormData = (booking: Booking | null, rooms: Room[], guests: Guest[]) => ({
    id: booking?.id || undefined,
    guestId: booking?.guestId || (guests.length > 0 ? guests[0].id : ''),
    roomId: booking?.roomId || (rooms.length > 0 ? rooms[0].id : ''),
    checkIn: booking ? toISODate(booking.checkIn) : todayStr,
    checkOut: booking ? toISODate(booking.checkOut) : toISODate(new Date(Date.now() + 86400000)),
    status: booking?.status || BookingStatus.Confirmed,
    totalPrice: booking?.totalPrice || 2500,
    payments: booking?.payments || [],
    source: booking?.source || 'Direct',
    bookType: booking?.bookType || 'BOOK_1',
});

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, onSave, booking, rooms, guests, existingBookings, propertyId, paymentModes, paymentAccounts, platformSettings, propertyManagementType }) => {
    const [formData, setFormData] = useState(getInitialFormData(booking, rooms, guests));
    const [newPayment, setNewPayment] = useState({ amount: 0, modeId: paymentModes[0]?.id || '', accountId: paymentAccounts[0]?.id || '' });

    const currencyFormatter = useMemo(() => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: platformSettings.currency,
            minimumFractionDigits: 2,
        });
    }, [platformSettings.currency]);

    useEffect(() => {
        setFormData(getInitialFormData(booking, rooms, guests));
    }, [booking, isOpen, rooms, guests]);

    const amountPaid = useMemo(() => formData.payments.reduce((acc, p) => acc + p.amount, 0), [formData.payments]);
    const balanceDue = useMemo(() => formData.totalPrice - amountPaid, [formData.totalPrice, amountPaid]);

    const availableRooms = useMemo(() => {
        const checkInDate = new Date(formData.checkIn).getTime();
        const checkOutDate = new Date(formData.checkOut).getTime();

        const bookedRoomIds = existingBookings
            .filter(b => {
                if (b.id === formData.id) return false;
                const existingCheckIn = new Date(b.checkIn).getTime();
                const existingCheckOut = new Date(b.checkOut).getTime();
                // A room is unavailable if a booking overlaps. For same-day checkout, checkOut time is exclusive.
                // So an existing booking from day 1 to day 2 (checkout) makes room available on day 2.
                // Overlap condition: (startA < endB) and (endA > startB)
                return checkInDate < existingCheckOut && checkOutDate > existingCheckIn;
            })
            .map(b => b.roomId);
        
        return rooms.filter(r => !bookedRoomIds.includes(r.id));
    }, [formData.checkIn, formData.checkOut, existingBookings, rooms, formData.id]);
    
    const handleMainChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'totalPrice' ? parseFloat(value) : value }));
    };

    const handlePaymentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setNewPayment(prev => ({ ...prev, [name]: name === 'amount' ? parseFloat(value) : value }));
    };
    
    const handleAddPayment = () => {
        if(newPayment.amount <= 0 || !newPayment.modeId || !newPayment.accountId) {
            alert("Please enter a valid amount and select payment mode/account.");
            return;
        }
        const paymentToAdd: Payment = { ...newPayment, date: todayStr };
        setFormData(prev => ({...prev, payments: [...prev.payments, paymentToAdd]}));
        setNewPayment({ amount: 0, modeId: paymentModes[0]?.id || '', accountId: paymentAccounts[0]?.id || '' });
    };
    
    const handleStatusUpdate = (newStatus: BookingStatus) => {
        const bookingToSave = { ...formData, propertyId, status: newStatus };
        if (propertyManagementType === 'SELF') {
            bookingToSave.bookType = 'BOOK_1';
        }
        onSave(bookingToSave);
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (new Date(formData.checkOut) < new Date(formData.checkIn)) {
            alert('Check-out date cannot be before check-in date.');
            return;
        }
        if (!formData.guestId || !formData.roomId) {
            alert('Please select a guest and a room.');
            return;
        }
        const bookingToSave = { ...formData, propertyId };
        if (propertyManagementType === 'SELF') {
            bookingToSave.bookType = 'BOOK_1';
        }
        onSave(bookingToSave);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-start py-10 overflow-y-auto" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl p-8" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-gray-800">{booking ? 'Edit Booking' : 'Create New Booking'}</h2>
                    {booking && (
                         <div className="flex space-x-2">
                            {formData.status === BookingStatus.Confirmed && <button type="button" onClick={() => handleStatusUpdate(BookingStatus.CheckedIn)} className="px-3 py-1 bg-green-500 text-white text-sm rounded-md hover:bg-green-600">Check In</button>}
                            {formData.status === BookingStatus.CheckedIn && <button type="button" onClick={() => handleStatusUpdate(BookingStatus.CheckedOut)} className="px-3 py-1 bg-blue-500 text-white text-sm rounded-md hover:bg-blue-600">Check Out</button>}
                            {formData.status !== BookingStatus.Cancelled && formData.status !== BookingStatus.CheckedOut && <button type="button" onClick={() => handleStatusUpdate(BookingStatus.Cancelled)} className="px-3 py-1 bg-red-500 text-white text-sm rounded-md hover:bg-red-600">Cancel Booking</button>}
                         </div>
                    )}
                </div>
                
                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                    {/* Main Booking Details */}
                    <div className="p-4 border rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-700 mb-4">Reservation Details</h3>
                        <div className="space-y-4">
                            <div>
                                <label htmlFor="guestId" className="block text-sm font-medium text-gray-700">Guest</label>
                                <select id="guestId" name="guestId" value={formData.guestId} onChange={handleMainChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm rounded-md" required>
                                    {guests.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="checkIn" className="block text-sm font-medium text-gray-700">Check-in</label>
                                    <input type="date" id="checkIn" name="checkIn" value={formData.checkIn} onChange={handleMainChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required/>
                                </div>
                                <div>
                                    <label htmlFor="checkOut" className="block text-sm font-medium text-gray-700">Check-out</label>
                                    <input type="date" id="checkOut" name="checkOut" value={formData.checkOut} onChange={handleMainChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required/>
                                </div>
                            </div>
                            <div>
                                <label htmlFor="roomId" className="block text-sm font-medium text-gray-700">Room</label>
                                <select id="roomId" name="roomId" value={formData.roomId} onChange={handleMainChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm rounded-md" required>
                                <option value="" disabled>Select an available room</option>
                                {availableRooms.map(r => <option key={r.id} value={r.id}>{r.name} - {r.type}</option>)}
                                {booking && !availableRooms.some(r => r.id === booking.roomId) && <option key={booking.roomId} value={booking.roomId}>{rooms.find(r => r.id === booking.roomId)?.name} (Current)</option>}
                                </select>
                                {availableRooms.length === 0 && !booking && <p className="text-xs text-red-600 mt-1">No rooms available for the selected dates.</p>}
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="status" className="block text-sm font-medium text-gray-700">Status</label>
                                    <select id="status" name="status" value={formData.status} onChange={handleMainChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm rounded-md" required>
                                        {Object.values(BookingStatus).map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                                    </select>
                                </div>
                                 <div>
                                    <label htmlFor="source" className="block text-sm font-medium text-gray-700">Source</label>
                                    <input type="text" id="source" name="source" value={formData.source} onChange={handleMainChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required/>
                                </div>
                            </div>
                            {propertyManagementType === 'OYO' && (
                                <div>
                                    <label htmlFor="bookType" className="block text-sm font-medium text-gray-700">Book <span className="text-red-500">*</span></label>
                                    <select id="bookType" name="bookType" value={formData.bookType} onChange={handleMainChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm rounded-md" required>
                                        <option value="BOOK_1">Book 1</option>
                                        <option value="BOOK_2">Book 2</option>
                                    </select>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Payment Section */}
                    <div className="p-4 border rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-700 mb-4">Payment</h3>
                        <div className="grid grid-cols-3 gap-4 mb-4 text-center">
                            <div><p className="text-sm text-gray-500">Total Price</p><p className="font-bold text-lg">{currencyFormatter.format(formData.totalPrice)}</p></div>
                            <div><p className="text-sm text-gray-500">Amount Paid</p><p className="font-bold text-lg text-green-600">{currencyFormatter.format(amountPaid)}</p></div>
                            <div><p className="text-sm text-gray-500">Balance Due</p><p className="font-bold text-lg text-red-600">{currencyFormatter.format(balanceDue)}</p></div>
                        </div>
                         <div>
                            <label htmlFor="totalPrice" className="block text-sm font-medium text-gray-700">Set Total Price</label>
                             <input type="number" id="totalPrice" name="totalPrice" value={formData.totalPrice} onChange={handleMainChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required/>
                        </div>

                        {/* Payment List */}
                        <div className="mt-4 space-y-2">
                             {formData.payments.map((p, i) => (
                                <div key={i} className="flex justify-between items-center bg-gray-50 p-2 rounded-md">
                                    <p className="text-sm">{paymentModes.find(m => m.id === p.modeId)?.name} to {paymentAccounts.find(a => a.id === p.accountId)?.name}</p>
                                    <p className="text-sm font-semibold">{currencyFormatter.format(p.amount)}</p>
                                </div>
                             ))}
                        </div>

                        {/* Add Payment Form */}
                        <div className="mt-4 pt-4 border-t">
                             <h4 className="font-semibold text-gray-600 mb-2">Add Payment</h4>
                             <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                                <div>
                                    <label htmlFor="paymentAmount" className="text-xs font-medium text-gray-600">Amount</label>
                                    <input type="number" id="paymentAmount" name="amount" value={newPayment.amount} onChange={handlePaymentChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"/>
                                </div>
                                <div>
                                     <label htmlFor="paymentMode" className="text-xs font-medium text-gray-600">Mode</label>
                                    <select id="paymentMode" name="modeId" value={newPayment.modeId} onChange={handlePaymentChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm">
                                        {paymentModes.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="paymentAccount" className="text-xs font-medium text-gray-600">Account</label>
                                    <select id="paymentAccount" name="accountId" value={newPayment.accountId} onChange={handlePaymentChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm">
                                        {paymentAccounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                                    </select>
                                </div>
                             </div>
                             <div className="text-right mt-2">
                                <button type="button" onClick={handleAddPayment} className="bg-blue-100 text-blue-800 font-semibold py-1 px-3 rounded-lg hover:bg-blue-200 transition-colors text-sm">Add Payment</button>
                             </div>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-3 pt-4">
                        <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">Cancel</button>
                        <button type="submit" className="bg-brand-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    );
};
