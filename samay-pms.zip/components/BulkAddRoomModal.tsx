
import React, { useState, useMemo } from 'react';
import { RoomType } from '../types';

interface BulkAddRoomModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (prefix: string, start: number, end: number, type: RoomType) => void;
}

export const BulkAddRoomModal: React.FC<BulkAddRoomModalProps> = ({ isOpen, onClose, onSave }) => {
    const [prefix, setPrefix] = useState('');
    const [start, setStart] = useState<number | ''>(101);
    const [end, setEnd] = useState<number | ''>(111);
    const [type, setType] = useState<RoomType>(RoomType.Double);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (typeof start !== 'number' || typeof end !== 'number' || start > end) {
            alert('Please enter a valid start and end room number range.');
            return;
        }
        if (end - start >= 100) {
            alert('You can only add up to 100 rooms at a time.');
            return;
        }
        onSave(prefix, start, end, type);
    };

    const roomsToCreate = useMemo(() => {
        if (typeof start === 'number' && typeof end === 'number' && end >= start) {
            return end - start + 1;
        }
        return 0;
    }, [start, end]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold text-gray-800">Bulk Add Rooms</h2>
                <p className="text-sm text-gray-500 mt-1">Quickly create multiple rooms with sequential numbers.</p>
                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                    <div>
                        <label htmlFor="prefix" className="block text-sm font-medium text-gray-700">Room Number Prefix (Optional)</label>
                        <input type="text" id="prefix" name="prefix" value={prefix} onChange={(e) => setPrefix(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" placeholder="e.g., A- or Floor1-" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="start" className="block text-sm font-medium text-gray-700">From</label>
                            <input type="number" id="start" name="start" value={start} onChange={(e) => setStart(e.target.value === '' ? '' : Number(e.target.value))} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required />
                        </div>
                        <div>
                            <label htmlFor="end" className="block text-sm font-medium text-gray-700">To</label>
                            <input type="number" id="end" name="end" value={end} onChange={(e) => setEnd(e.target.value === '' ? '' : Number(e.target.value))} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="type" className="block text-sm font-medium text-gray-700">Room Type</label>
                        <select id="type" name="type" value={type} onChange={(e) => setType(e.target.value as RoomType)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required>
                            {Object.values(RoomType).map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                    </div>

                    {roomsToCreate > 0 && (
                        <div className="p-3 bg-blue-50 border border-blue-200 text-blue-800 rounded-md text-sm">
                            You are about to create <strong>{roomsToCreate}</strong> rooms (from {prefix}{start} to {prefix}{end}) of type <strong>{type}</strong>.
                        </div>
                    )}

                    <div className="flex justify-end space-x-3 pt-4">
                        <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">Cancel</button>
                        <button type="submit" className="bg-brand-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Add Rooms</button>
                    </div>
                </form>
            </div>
        </div>
    );
};
