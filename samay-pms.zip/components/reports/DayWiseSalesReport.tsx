
import React, { useMemo } from 'react';
import { Booking, PlatformSettings } from '../../types';
import { DateRange } from './common/ReportDateFilter';

interface DayWiseSalesReportProps {
    bookings: Booking[];
    dateRange: DateRange;
    platformSettings: PlatformSettings;
}

export const DayWiseSalesReport: React.FC<DayWiseSalesReportProps> = ({ bookings, dateRange, platformSettings }) => {

    const currencyFormatter = useMemo(() => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: platformSettings.currency,
            minimumFractionDigits: 2,
        });
    }, [platformSettings.currency]);

    const salesData = useMemo(() => {
        const from = new Date(dateRange.from).getTime();
        const to = new Date(dateRange.to).getTime();

        const filteredBookings = bookings.filter(b => {
            const checkInTime = new Date(b.checkIn).getTime();
            return checkInTime >= from && checkInTime <= to;
        });

        const dailySales = filteredBookings.reduce((acc, booking) => {
            const date = booking.checkIn;
            if (!acc[date]) {
                acc[date] = { total: 0, count: 0 };
            }
            acc[date].total += booking.totalPrice;
            acc[date].count += 1;
            return acc;
        }, {} as { [key: string]: { total: number, count: number } });

        return Object.entries(dailySales)
            .map(([date, data]) => ({ date, ...data }))
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    }, [bookings, dateRange]);

    const totalRevenue = salesData.reduce((acc, item) => acc + item.total, 0);
    const totalBookings = salesData.reduce((acc, item) => acc + item.count, 0);

    return (
        <div>
            <h4 className="text-xl font-bold text-gray-800 mb-4">Day-wise Sales Report</h4>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="py-2 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                            <th className="py-2 px-4 text-center text-sm font-semibold text-gray-700">Bookings</th>
                            <th className="py-2 px-4 text-right text-sm font-semibold text-gray-700">Total Sales</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {salesData.map(item => (
                            <tr key={item.date}>
                                <td className="py-2 px-4">{new Date(item.date).toLocaleDateString()}</td>
                                <td className="py-2 px-4 text-center font-medium">{item.count}</td>
                                <td className="py-2 px-4 text-right font-medium">{currencyFormatter.format(item.total)}</td>
                            </tr>
                        ))}
                         {salesData.length === 0 && (
                            <tr>
                                <td colSpan={3} className="text-center py-4 text-gray-500">No sales data for the selected period.</td>
                            </tr>
                        )}
                    </tbody>
                    <tfoot className="bg-gray-50 font-bold">
                        <tr>
                            <td className="py-2 px-4 text-left">Total</td>
                            <td className="py-2 px-4 text-center">{totalBookings}</td>
                            <td className="py-2 px-4 text-right">{currencyFormatter.format(totalRevenue)}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    );
};
