
import React, { useState, useEffect } from 'react';

export interface DateRange {
    from: string;
    to: string;
}

interface ReportDateFilterProps {
    onDateChange: (range: DateRange) => void;
}

const toISODate = (d: Date) => d.toISOString().split('T')[0];

const datePresets: { [key: string]: () => DateRange } = {
    'Today': () => {
        const today = new Date();
        return { from: toISODate(today), to: toISODate(today) };
    },
    'Tomorrow': () => {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        return { from: toISODate(tomorrow), to: toISODate(tomorrow) };
    },
    'Yesterday': () => {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        return { from: toISODate(yesterday), to: toISODate(yesterday) };
    },
    'This Week': () => {
        const today = new Date();
        const first = today.getDate() - today.getDay();
        const last = first + 6;
        const from = new Date(today.setDate(first));
        const to = new Date(new Date().setDate(last));
        return { from: toISODate(from), to: toISODate(to) };
    },
    'Last Week': () => {
        const today = new Date();
        const first = today.getDate() - today.getDay() - 7;
        const last = first + 6;
        const from = new Date(today.setDate(first));
        const to = new Date(new Date().setDate(last));
        return { from: toISODate(from), to: toISODate(to) };
    },
    'This Month': () => {
        const today = new Date();
        const from = new Date(today.getFullYear(), today.getMonth(), 1);
        const to = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        return { from: toISODate(from), to: toISODate(to) };
    },
    'Last Month': () => {
        const today = new Date();
        const from = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const to = new Date(today.getFullYear(), today.getMonth(), 0);
        return { from: toISODate(from), to: toISODate(to) };
    },
    'This Quarter': () => {
        const today = new Date();
        const quarter = Math.floor(today.getMonth() / 3);
        const from = new Date(today.getFullYear(), quarter * 3, 1);
        const to = new Date(from.getFullYear(), from.getMonth() + 3, 0);
        return { from: toISODate(from), to: toISODate(to) };
    },
    'Last Quarter': () => {
        const today = new Date();
        const quarter = Math.floor(today.getMonth() / 3);
        const from = new Date(today.getFullYear(), (quarter - 1) * 3, 1);
        const to = new Date(from.getFullYear(), from.getMonth() + 3, 0);
        return { from: toISODate(from), to: toISODate(to) };
    },
    'This Year': () => {
        const today = new Date();
        const from = new Date(today.getFullYear(), 0, 1);
        const to = new Date(today.getFullYear(), 11, 31);
        return { from: toISODate(from), to: toISODate(to) };
    },
    'Last Year': () => {
        const today = new Date();
        const from = new Date(today.getFullYear() - 1, 0, 1);
        const to = new Date(today.getFullYear() - 1, 11, 31);
        return { from: toISODate(from), to: toISODate(to) };
    },
};

const FilterButton: React.FC<{ label: string; onClick: () => void; isActive: boolean; }> = ({ label, onClick, isActive }) => (
    <button
        onClick={onClick}
        className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
            isActive ? 'bg-brand-primary text-white shadow' : 'text-gray-600 bg-gray-100 hover:bg-gray-200'
        }`}
    >
        {label}
    </button>
);

export const ReportDateFilter: React.FC<ReportDateFilterProps> = ({ onDateChange }) => {
    const [activeButton, setActiveButton] = useState('This Month');
    const [customFrom, setCustomFrom] = useState('');
    const [customTo, setCustomTo] = useState('');

    useEffect(() => {
        handlePresetClick('This Month');
    }, []);

    const handlePresetClick = (label: string) => {
        setActiveButton(label);
        const range = datePresets[label]();
        onDateChange(range);
        setCustomFrom(range.from);
        setCustomTo(range.to);
    };
    
    const handleCustomDateChange = () => {
        if(customFrom && customTo) {
            setActiveButton('Custom');
            onDateChange({ from: customFrom, to: customTo });
        }
    }

    useEffect(() => {
        handleCustomDateChange();
    }, [customFrom, customTo]);

    return (
        <div className="flex flex-wrap items-center gap-2">
            {Object.keys(datePresets).map(label => (
                <FilterButton
                    key={label}
                    label={label}
                    onClick={() => handlePresetClick(label)}
                    isActive={activeButton === label}
                />
            ))}
            <div className="flex items-center gap-2 ml-4 border-l pl-4">
                <input 
                    type="date"
                    value={customFrom}
                    onChange={e => setCustomFrom(e.target.value)}
                    className="px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm"
                />
                 <span className="text-gray-500">to</span>
                 <input 
                    type="date"
                    value={customTo}
                    onChange={e => setCustomTo(e.target.value)}
                    className="px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm"
                />
            </div>
        </div>
    );
};
