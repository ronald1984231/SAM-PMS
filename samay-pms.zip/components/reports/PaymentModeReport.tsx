
import React, { useMemo } from 'react';
import { Booking, PaymentMode, PlatformSettings } from '../../types';
import { DateRange } from './common/ReportDateFilter';

interface PaymentModeReportProps {
    bookings: Booking[];
    paymentModes: PaymentMode[];
    dateRange: DateRange;
    platformSettings: PlatformSettings;
}

export const PaymentModeReport: React.FC<PaymentModeReportProps> = ({ bookings, paymentModes, dateRange, platformSettings }) => {
    
    const currencyFormatter = useMemo(() => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: platformSettings.currency,
            minimumFractionDigits: 2,
        });
    }, [platformSettings.currency]);

    const reportData = useMemo(() => {
        const from = new Date(dateRange.from).getTime();
        const to = new Date(dateRange.to).getTime();
        const modeMap = new Map(paymentModes.map(mode => [mode.id, { name: mode.name, total: 0 }]));

        bookings.forEach(booking => {
            booking.payments.forEach(payment => {
                const paymentDate = new Date(payment.date).getTime();
                if (paymentDate >= from && paymentDate <= to) {
                    if (modeMap.has(payment.modeId)) {
                        const current = modeMap.get(payment.modeId)!;
                        current.total += payment.amount;
                    }
                }
            });
        });

        return Array.from(modeMap.values()).sort((a, b) => b.total - a.total);

    }, [bookings, paymentModes, dateRange]);
    
    const totalReceived = reportData.reduce((acc, item) => acc + item.total, 0);

    return (
        <div>
            <h4 className="text-xl font-bold text-gray-800 mb-4">Payment Mode Report</h4>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="py-2 px-4 text-left text-sm font-semibold text-gray-700">Payment Mode</th>
                            <th className="py-2 px-4 text-right text-sm font-semibold text-gray-700">Total Amount Received</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {reportData.map(item => (
                            <tr key={item.name}>
                                <td className="py-2 px-4">{item.name}</td>
                                <td className="py-2 px-4 text-right font-medium">{currencyFormatter.format(item.total)}</td>
                            </tr>
                        ))}
                         {reportData.length === 0 && (
                            <tr>
                                <td colSpan={2} className="text-center py-4 text-gray-500">No payment data for the selected period.</td>
                            </tr>
                        )}
                    </tbody>
                    <tfoot className="bg-gray-50 font-bold">
                        <tr>
                            <td className="py-2 px-4 text-left">Total</td>
                            <td className="py-2 px-4 text-right">{currencyFormatter.format(totalReceived)}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    );
};
