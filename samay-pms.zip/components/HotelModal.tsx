
import React, { useState, useEffect } from 'react';
import { Property } from '../types';

interface HotelModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (property: Omit<Property, 'id' | 'customerId'> & { id?: string }) => void;
    property: Property | null;
}

const getInitialData = (property: Property | null) => ({
    name: property?.name || '',
    location: property?.location || '',
    phone: property?.phone || '',
    managementType: property?.managementType || 'SELF',
});

export const HotelModal: React.FC<HotelModalProps> = ({ isOpen, onClose, onSave, property }) => {
    const [formData, setFormData] = useState(getInitialData(property));

    useEffect(() => {
        setFormData(getInitialData(property));
    }, [property, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.name && formData.location) {
            onSave({ id: property?.id, ...formData } as Omit<Property, 'id' | 'customerId'> & { id?: string });
        } else {
            alert('Hotel Name and Location are required.');
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold text-gray-800">{property ? 'Edit Hotel' : 'Add New Hotel'}</h2>
                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700">Hotel Name</label>
                        <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required />
                    </div>
                    <div>
                        <label htmlFor="location" className="block text-sm font-medium text-gray-700">Location</label>
                        <input type="text" id="location" name="location" value={formData.location} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" required />
                    </div>
                    <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
                        <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Management Type</label>
                         <div className="mt-2 flex space-x-4">
                            <label className="flex items-center">
                                <input type="radio" name="managementType" value="SELF" checked={formData.managementType === 'SELF'} onChange={handleChange} className="focus:ring-brand-primary h-4 w-4 text-brand-primary border-gray-300" />
                                <span className="ml-2 text-sm text-gray-700">Self Managed</span>
                            </label>
                            <label className="flex items-center">
                                <input type="radio" name="managementType" value="OYO" checked={formData.managementType === 'OYO'} onChange={handleChange} className="focus:ring-brand-primary h-4 w-4 text-brand-primary border-gray-300" />
                                <span className="ml-2 text-sm text-gray-700">Oyo Managed</span>
                            </label>
                         </div>
                    </div>
                    <div className="flex justify-end space-x-3 pt-4">
                        <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">Cancel</button>
                        <button type="submit" className="bg-brand-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Save Hotel</button>
                    </div>
                </form>
            </div>
        </div>
    );
};