
import React from 'react';
import { Property } from '../types';

interface HeaderProps {
    properties: Property[];
    selectedProperty: Property;
    onPropertyChange: (propertyId: string) => void;
    onViewChange: () => void;
}

const BellIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
    </svg>
);

const AdminIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clipRule="evenodd" />
    </svg>
);


export const Header: React.FC<HeaderProps> = ({ properties, selectedProperty, onPropertyChange, onViewChange }) => {
    return (
        <header className="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10">
            <div className="flex items-center">
                <h2 className="text-xl font-semibold text-gray-800">{selectedProperty.name}</h2>
                <span className="mx-2 text-gray-300">|</span>
                <p className="text-sm text-gray-500">{selectedProperty.location}</p>
            </div>
            <div className="flex items-center space-x-4">
                <div className="relative">
                    <select
                        value={selectedProperty.id}
                        onChange={(e) => onPropertyChange(e.target.value)}
                        className="appearance-none bg-gray-100 border border-gray-300 rounded-md py-2 pl-3 pr-8 text-sm font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary"
                    >
                        {properties.map(prop => (
                            <option key={prop.id} value={prop.id}>{prop.name}</option>
                        ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                        <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                    </div>
                </div>

                <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none" title="Notifications">
                    <BellIcon />
                </button>
                
                <div className="flex items-center space-x-3">
                    <img className="h-10 w-10 rounded-full object-cover" src="https://picsum.photos/100/100" alt="User" />
                    <div>
                        <p className="text-sm font-medium text-gray-800">Admin User</p>
                        <p className="text-xs text-gray-500">System Administrator</p>
                    </div>
                </div>
                 <button className="p-2 rounded-full text-gray-500 hover:bg-red-100 hover:text-red-600 focus:outline-none" title="Super Admin Panel" onClick={onViewChange}>
                    <AdminIcon className="h-6 w-6" />
                </button>
            </div>
        </header>
    );
};
