
import React, { useState } from 'react';
import { SuperAdminSidebar } from './SuperAdminSidebar';
import { SuperAdminPage, SaaS_Customer, Property, User, SystemLog } from '../../types';
import { SaaSDashboard } from '../../pages/superadmin/SaaSDashboard';
import { Customers } from '../../pages/superadmin/Customers';
import { SystemHealth } from '../../pages/superadmin/SystemHealth';

interface SuperAdminPanelProps {
    onViewChange: () => void;
    customers: SaaS_Customer[];
    properties: Property[];
    users: User[];
    systemLogs: SystemLog[];
}

export const SuperAdminPanel: React.FC<SuperAdminPanelProps> = ({ onViewChange, customers, properties, users, systemLogs }) => {
    const [currentPage, setCurrentPage] = useState<SuperAdminPage>('saas-dashboard');
    
    const renderPage = () => {
        switch (currentPage) {
            case 'saas-dashboard':
                return <SaaSDashboard customers={customers} properties={properties} users={users} />;
            case 'saas-customers':
                return <Customers customers={customers} properties={properties} />;
            case 'saas-system-health':
                return <SystemHealth systemLogs={systemLogs} />;
            default:
                return <SaaSDashboard customers={customers} properties={properties} users={users} />;
        }
    };

    return (
        <div className="flex h-screen bg-gray-900 font-sans text-white">
            <SuperAdminSidebar currentPage={currentPage} setCurrentPage={setCurrentPage} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <header className="h-16 bg-gray-800 shadow-md flex items-center justify-between px-6 z-10">
                    <h2 className="text-xl font-semibold">Super Admin Panel</h2>
                    <button onClick={onViewChange} className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 font-semibold">
                        Return to Hotel View
                    </button>
                </header>
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-900 p-8">
                    {renderPage()}
                </main>
            </div>
        </div>
    );
};
