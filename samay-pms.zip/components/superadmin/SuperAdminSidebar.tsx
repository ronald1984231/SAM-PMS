
import React from 'react';
import { SuperAdminPage } from '../../types';
import { SUPER_ADMIN_NAV_ITEMS } from '../../constants';

interface SuperAdminSidebarProps {
    currentPage: SuperAdminPage;
    setCurrentPage: (page: SuperAdminPage) => void;
}

export const SuperAdminSidebar: React.FC<SuperAdminSidebarProps> = ({ currentPage, setCurrentPage }) => {
    return (
        <aside className="w-64 bg-gray-800 text-gray-300 flex flex-col">
            <div className="h-16 flex items-center justify-center border-b border-gray-700">
                <h1 className="text-2xl font-bold tracking-wider text-white">SAAS ADMIN</h1>
            </div>
            <nav className="flex-1 px-4 py-6 space-y-2">
                {SUPER_ADMIN_NAV_ITEMS.map((item) => {
                    const isActive = currentPage === item.id;
                    return (
                        <a
                            key={item.id}
                            href="#"
                            onClick={(e) => {
                                e.preventDefault();
                                setCurrentPage(item.id);
                            }}
                            className={`flex items-center px-4 py-3 rounded-lg transition-colors duration-200 ${
                                isActive ? 'bg-blue-600 text-white' : 'hover:bg-gray-700'
                            }`}
                        >
                            <item.icon className="h-6 w-6 mr-3" />
                            <span className="font-medium">{item.label}</span>
                        </a>
                    );
                })}
            </nav>
            <div className="px-4 py-4 border-t border-gray-700">
                <p className="text-xs text-gray-500">Platform Management Interface</p>
            </div>
        </aside>
    );
};
