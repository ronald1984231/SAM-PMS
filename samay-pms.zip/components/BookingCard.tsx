
import React, { useState, useMemo } from 'react';
import { Booking, Guest, BookingStatus, PlatformSettings, Room, RoomType } from '../types';
import { ActionButtons } from './ActionButtons';

interface BookingCardProps {
    booking: Booking;
    guest?: Guest;
    room?: Room;
    onView: () => void;
    onEdit: () => void;
    onDelete: () => void;
    platformSettings: PlatformSettings;
    isOyoManaged: boolean;
}

const statusConfig: {[key in BookingStatus]: {label: string, color: string}} = {
    [BookingStatus.Confirmed]: { label: 'Confirmed', color: 'bg-blue-100 text-blue-800' },
    [BookingStatus.CheckedIn]: { label: 'Checked-In', color: 'bg-green-100 text-green-800' },
    [BookingStatus.CheckedOut]: { label: 'Checked-Out', color: 'bg-gray-100 text-gray-800' },
    [BookingStatus.Cancelled]: { label: 'Cancelled', color: 'bg-red-100 text-red-800' },
};

const BookTypeBadge: React.FC<{ bookType?: 'BOOK_1' | 'BOOK_2' }> = ({ bookType }) => {
    if (!bookType) return null;
    const isBook1 = bookType === 'BOOK_1';
    return (
        <span className={`ml-2 px-2 py-0.5 text-xs font-semibold rounded-full ${isBook1 ? 'bg-purple-100 text-purple-800' : 'bg-indigo-100 text-indigo-800'}`}>
            {isBook1 ? 'Book 1' : 'Book 2'}
        </span>
    );
};


export const BookingCard: React.FC<BookingCardProps> = ({ booking, guest, room, onView, onEdit, onDelete, platformSettings, isOyoManaged }) => {

    const currencyFormatter = useMemo(() => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: platformSettings.currency,
            minimumFractionDigits: 2,
        });
    }, [platformSettings.currency]);
    
    const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('en-CA');

    const amountPaid = booking.payments.reduce((acc, p) => acc + p.amount, 0);
    const balanceDue = booking.totalPrice - amountPaid;

    return (
        <div className="bg-white rounded-lg shadow-sm border grid grid-cols-12 items-center text-sm">
            <div className="col-span-1 p-3">
                <input type="checkbox" className="h-4 w-4 rounded border-gray-300 text-brand-primary focus:ring-brand-primary" />
            </div>
            {/* Guest & Room */}
            <div className="col-span-3 p-3">
                <p className="font-bold text-gray-900">{guest?.name || 'Guest Not Found'}</p>
                <p className="text-gray-500">{guest?.phone}</p>
                <p className="text-gray-500 font-semibold">{room?.name || 'N/A'} - {room?.type}</p>
            </div>
            {/* Dates */}
            <div className="col-span-2 p-3">
                <p><span className="font-semibold">In:</span> {formatDate(booking.checkIn)}</p>
                <p><span className="font-semibold">Out:</span> {formatDate(booking.checkOut)}</p>
            </div>
            {/* Status */}
            <div className="col-span-2 p-3">
                <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${statusConfig[booking.status].color}`}>
                    {statusConfig[booking.status].label}
                </span>
                {isOyoManaged && <BookTypeBadge bookType={booking.bookType} />}
            </div>
             {/* Payment */}
            <div className="col-span-2 p-3 text-right">
                <p className="font-bold">{currencyFormatter.format(booking.totalPrice)}</p>
                {balanceDue > 0 ? (
                     <p className="text-red-600 font-semibold">{currencyFormatter.format(balanceDue)} Due</p>
                ) : (
                    <p className="text-green-600 font-semibold">Paid</p>
                )}
            </div>
            {/* Actions */}
            <div className="col-span-2 p-3 flex justify-end">
                <ActionButtons onView={onView} onEdit={onEdit} onDelete={onDelete} />
            </div>
        </div>
    );
};