import { Property, Room, Guest, Booking, RevenueDataPoint, BookingStatus, RoomType, HousekeepingStatus, User, Integration, IntegrationCategory, AuditLog, PlatformSettings, PaymentMode, PaymentAccount, Payment, SaaS_Customer, SubscriptionPlan, SystemLog } from '../types';


export const mockSaasCustomers: SaaS_Customer[] = [
    { id: 'cust1', name: 'Grand Horizon Group', status: 'Active', subscriptionPlanId: 'pro', memberSince: '2023-01-15' },
    { id: 'cust2', name: 'Azure Resorts Inc.', status: 'Active', subscriptionPlanId: 'enterprise', memberSince: '2022-11-20' },
    { id: 'cust3', name: 'Metropolis Stays', status: 'Trial', subscriptionPlanId: 'basic', memberSince: '2024-05-01' },
];

export const mockSubscriptionPlans: SubscriptionPlan[] = [
    { name: 'Basic', monthlyRate: 99, propertyLimit: 1, userLimit: 5 },
    { name: 'Pro', monthlyRate: 249, propertyLimit: 5, userLimit: 25 },
    { name: 'Enterprise', monthlyRate: 599, propertyLimit: 50, userLimit: 200 },
];

export const mockProperties: Property[] = [];

export const mockRooms: Room[] = [];

export const mockGuests: Guest[] = [];

export const mockUsers: User[] = [
    { id: 'user1', name: 'Admin User', role: 'Admin' },
    { id: 'user2', name: 'Emily Manager', role: 'Manager' },
    { id: 'user3', name: 'John Staff', role: 'Staff' },
];

export const mockPlatformSettings: PlatformSettings = {
    currency: 'INR',
    timezone: 'Asia/Kolkata',
};

export const mockPaymentModes: PaymentMode[] = [
    { id: 'pm_card', name: 'Credit/Debit Card' },
    { id: 'pm_upi', name: 'UPI' },
    { id: 'pm_cash', name: 'Cash' },
    { id: 'pm_bank', name: 'Bank Transfer' },
];

export const mockPaymentAccounts: PaymentAccount[] = [
    { id: 'pa_samay', name: 'Samay UPI/Card', details: 'Payments managed by Samay' },
    { id: 'pa_manish', name: 'Manish UPI/Card', details: 'Payments managed by Manish' },
    { id: 'pa_cash', name: 'Cash Received', details: 'Physical cash received' },
    { id: 'pa_oyo', name: 'OYO Received', details: 'Payments from OYO channel' },
];


export const mockBookings: Booking[] = [];

export const mockRevenueData: { [key: string]: RevenueDataPoint[] } = {};

export const mockIntegrations: Integration[] = [
    {
        id: 'int1',
        name: 'Stripe',
        category: IntegrationCategory.PaymentGateway,
        description: 'Accept payments from anyone, anywhere.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/stripe-4.svg',
        connected: true,
        credentials: { publishableKey: 'pk_test_1234567890abcdef', secretKey: 'sk_test_1234567890abcdef' },
    },
    {
        id: 'int2',
        name: 'Booking.com',
        category: IntegrationCategory.ChannelManager,
        description: 'Sync your bookings with the world\'s leading OTA.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/bookingcom-1.svg',
        connected: true,
        credentials: { apiKey: 'abcdef123456', hotelId: '12345' },
    },
    {
        id: 'int3',
        name: 'Expedia',
        category: IntegrationCategory.ChannelManager,
        description: 'Connect to millions of travelers on Expedia.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/expedia-1.svg',
        connected: false,
        credentials: { apiKey: '', hotelId: '' },
    },
    {
        id: 'int4',
        name: 'QuickBooks',
        category: IntegrationCategory.Accounting,
        description: 'Automate your accounting and financial reporting.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/quickbooks-6.svg',
        connected: false,
        credentials: { apiKey: '' },
    },
    {
        id: 'int5',
        name: 'Toast POS',
        category: IntegrationCategory.POS,
        description: 'Sync your restaurant sales with guest folios.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/toast-1.svg',
        connected: true,
        credentials: { apiKey: 'toast_api_key_12345' },
    },
    {
        id: 'int6',
        name: 'WhatsApp Business',
        category: IntegrationCategory.Communication,
        description: 'Send hourly reports and booking alerts via WhatsApp.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/whatsapp-3.svg',
        connected: false,
        credentials: { apiToken: '', phoneNumberId: '' },
    },
    {
        id: 'int7',
        name: 'Twilio',
        category: IntegrationCategory.Communication,
        description: 'Deliver automated SMS reports and guest notifications.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/twilio-2.svg',
        connected: false,
        credentials: { accountSid: '', authToken: '', phoneNumber: '' },
    },
    {
        id: 'int8',
        name: 'Email Reports',
        category: IntegrationCategory.Communication,
        description: 'Configure and receive daily/weekly email summary reports.',
        logoUrl: 'https://cdn.worldvectorlogo.com/logos/mail-ios.svg',
        connected: true,
        credentials: { recipients: 'manager@hotel.com', frequency: 'Daily' },
    }
];

export const mockAuditLogs: AuditLog[] = [
    { id: 'log1', timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(), userId: 'user1', action: 'LOGIN', details: 'User logged in successfully from IP 192.168.1.1' },
    { id: 'log2', timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(), userId: 'user2', action: 'UPDATE_BOOKING', details: 'Updated booking b2 status to CONFIRMED' },
    { id: 'log3', timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString(), userId: 'user3', action: 'UPDATE_HOUSEKEEPING', details: 'Room r103 status changed to Dirty' },
    { id: 'log4', timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(), userId: 'user1', action: 'TOGGLE_INTEGRATION', details: 'Integration "Toast POS" was connected' },
    { id: 'log5', timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(), userId: 'user2', action: 'CREATE_BOOKING', details: 'New booking b8 created for guest Jane Smith' },
    { id: 'log6', timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), userId: 'user1', action: 'LOGIN_FAILED', details: 'Failed login attempt for user "Admin User"' },
];

export const mockSystemLogs: SystemLog[] = [
    { id: 'slog1', timestamp: new Date(Date.now() - 1 * 60 * 1000).toISOString(), level: 'INFO', service: 'API', message: 'Endpoint GET /api/v1/bookings responded in 25ms' },
    { id: 'slog2', timestamp: new Date(Date.now() - 3 * 60 * 1000).toISOString(), level: 'ERROR', service: 'DATABASE', message: 'Connection timeout to primary cluster. Failing over to replica.' },
    { id: 'slog3', timestamp: new Date(Date.now() - 4 * 60 * 1000).toISOString(), level: 'INFO', service: 'DATABASE', message: 'Failover to replica successful. Read-only mode activated.' },
    { id: 'slog4', timestamp: new Date(Date.now() - 8 * 60 * 1000).toISOString(), level: 'WARN', service: 'AUTH', message: 'Rate limit exceeded for IP 88.12.34.56' },
    { id: 'slog5', timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), level: 'INFO', service: 'BACKGROUND_JOB', message: 'Nightly audit job completed successfully. Processed 1254 records.' },
];