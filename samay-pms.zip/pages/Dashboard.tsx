
import React, { useMemo } from 'react';
import { Booking, Room, BookingStatus } from '../types';

interface DashboardCardProps {
    title: string;
    value: string | number;
    icon: React.ReactNode;
}

const InfoCard: React.FC<DashboardCardProps> = ({ title, value, icon }) => (
    <div className="bg-white p-4 rounded-lg shadow flex items-center space-x-4">
        <div className="text-brand-primary">
            {icon}
        </div>
        <div>
            <p className="text-3xl font-bold text-gray-800">{value}</p>
            <p className="text-sm font-medium text-gray-500">{title}</p>
        </div>
    </div>
);

const OccupiedIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.225-1.264-.62-1.751M17 20h-2M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.225-1.264.62-1.751M7 20h2m-4-2h12M9 4H7a2 2 0 00-2 2v8a2 2 0 002 2h10a2 2 0 002-2v-8a2 2 0 00-2-2h-2M9 4V3a1 1 0 011-1h4a1 1 0 011 1v1M9 4h6" /></svg>;
const VacantIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" /></svg>;
const ArrivalIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>;
const DepartureIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16l4-4m0 0l-4-4m4 4H3m13 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013 3v1" /></svg>;


interface DashboardProps {
    rooms: Room[];
    bookings: Booking[];
}

export const Dashboard: React.FC<DashboardProps> = ({ rooms, bookings }) => {
    
    const todayStr = new Date().toISOString().split('T')[0];

    const stats = useMemo(() => {
        const occupiedRooms = new Set(bookings.filter(b => b.status === BookingStatus.CheckedIn).map(b => b.roomId));
        const vacantRooms = rooms.length - occupiedRooms.size;
        const expectedArrivals = bookings.filter(b => b.checkIn === todayStr && b.status === BookingStatus.Confirmed).length;
        const expectedDepartures = bookings.filter(b => b.checkOut === todayStr && b.status === BookingStatus.CheckedIn).length;
        const checkedInToday = bookings.filter(b => b.checkIn === todayStr && b.status === BookingStatus.CheckedIn).length;
        const checkedOutToday = bookings.filter(b => b.checkOut === todayStr && b.status === BookingStatus.CheckedOut).length;

        return {
            occupiedRooms: occupiedRooms.size,
            vacantRooms,
            expectedArrivals,
            expectedDepartures,
            checkedInToday,
            checkedOutToday,
        };
    }, [rooms, bookings, todayStr]);

    return (
        <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-gray-800">Today's Overview</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <InfoCard title="Occupied Rooms" value={stats.occupiedRooms} icon={<OccupiedIcon />} />
                <InfoCard title="Vacant Rooms" value={stats.vacantRooms} icon={<VacantIcon />} />
                <InfoCard title="Expected Arrival" value={stats.expectedArrivals} icon={<ArrivalIcon />} />
                <InfoCard title="Expected Departure" value={stats.expectedDepartures} icon={<DepartureIcon />} />
                <InfoCard title="Today's Checked In" value={stats.checkedInToday} icon={<ArrivalIcon />} />
                <InfoCard title="Today's Checked Out" value={stats.checkedOutToday} icon={<DepartureIcon />} />
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                 <h3 className="text-xl font-semibold text-gray-800">Quick Actions</h3>
                 <p className="text-gray-500 mt-2">Navigate using the sidebar to manage reservations, rooms, guests, and more.</p>
                 {/* Can add more components here later, like recent activity feed */}
            </div>
        </div>
    );
};
