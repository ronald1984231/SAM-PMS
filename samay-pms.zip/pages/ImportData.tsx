import React, { useState, useMemo, useEffect } from 'react';
import { Room, Guest } from '../types';

declare const Papa: any;
declare const XLSX: any;

interface ImportDataProps {
    rooms: Room[];
    guests: Guest[];
    onImportBookings: (data: any[]) => void;
}

type Step = 1 | 2 | 3;

const WIZARD_STEPS = [
    { number: 1, title: 'Upload File' },
    { number: 2, title: 'Map Columns' },
    { number: 3, title: 'Preview & Import' }
];

const REQUIRED_FIELDS = ['guestName', 'checkIn', 'checkOut', 'roomName', 'totalPrice'];
const OPTIONAL_FIELDS = ['guestEmail', 'guestPhone', 'source', 'bookType'];
const ALL_FIELDS = [...REQUIRED_FIELDS, ...OPTIONAL_FIELDS];

function parseDate(dateInput: string | number | Date): Date | null {
    if (dateInput instanceof Date && !isNaN(dateInput.getTime())) {
        return dateInput;
    }

    if (typeof dateInput === 'number' && dateInput > 1) {
        const excelDate = new Date((dateInput - 25569) * 86400 * 1000);
        if (dateInput < 60) excelDate.setDate(excelDate.getDate() - 1);
        return excelDate;
    }

    if (typeof dateInput !== 'string') return null;
    
    const str = dateInput.trim();
    let date = new Date(str);
    if (!isNaN(date.getTime())) return date;

    const specialFormatMatch = str.match(/^(\d{1,2})-(\w{3})-(\d{4})$/);
    if (specialFormatMatch) {
        const day = parseInt(specialFormatMatch[1], 10);
        const monthStr = specialFormatMatch[2].toLowerCase();
        const year = parseInt(specialFormatMatch[3], 10);
        const monthMap: { [key: string]: number } = {'jan':0,'feb':1,'mar':2,'apr':3,'may':4,'jun':5,'jul':6,'aug':7,'sep':8,'oct':9,'nov':10,'dec':11};
        const monthIndex = monthMap[monthStr];
        if (day && monthIndex !== undefined && year) {
            date = new Date(Date.UTC(year, monthIndex, day));
            if (!isNaN(date.getTime())) return date;
        }
    }
    return null;
}

export const ImportData: React.FC<ImportDataProps> = ({ rooms, guests, onImportBookings }) => {
    const [step, setStep] = useState<Step>(1);
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState('');
    const [parsedData, setParsedData] = useState<any[]>([]);
    const [headers, setHeaders] = useState<string[]>([]);
    const [mapping, setMapping] = useState<{ [key: string]: string }>({});
    const [isParsing, setIsParsing] = useState(false);
    
    const [editablePreviewData, setEditablePreviewData] = useState<any[]>([]);
    const [showOnlyErrors, setShowOnlyErrors] = useState(false);

    const roomNames = new Set(rooms.map(r => r.name.toLowerCase()));

    const processParsedData = (data: any[], fields: string[]) => {
        setHeaders(fields);
        setParsedData(data);
        
        const mappingAliases: { [key: string]: string[] } = {
            guestName: ['guestname', 'guest', 'name', 'fullname'],
            checkIn: ['checkin', 'check-in', 'arrivaldate', 'arrival'],
            checkOut: ['checkout', 'check-out', 'departuredate', 'departure'],
            roomName: ['roomname', 'roomno', 'roomnumber', 'roomnum'],
            totalPrice: ['totalprice', 'price', 'totalamount', 'amount'],
            guestEmail: ['guestemail', 'email'],
            guestPhone: ['guestphone', 'phone', 'phonenumber', 'mobile'],
            source: ['source', 'channel'],
            bookType: ['booktype', 'book'],
        };
        
        const newMapping: { [key: string]: string } = {};
        ALL_FIELDS.forEach(field => {
            const aliases = mappingAliases[field] || [field.toLowerCase()];
            for (const alias of aliases) {
                const matchedHeader = fields.find(h => h.toLowerCase().replace(/[\s_]/g, '') === alias);
                if (matchedHeader) {
                    newMapping[field] = matchedHeader;
                    break;
                }
            }
        });

        setMapping(newMapping);
        setIsParsing(false);
        setStep(2);
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = event.target.files?.[0];
        if (selectedFile) {
            setIsParsing(true);
            setFile(selectedFile);
            setFileName(selectedFile.name);
            const fileExtension = selectedFile.name.split('.').pop()?.toLowerCase();

            if (fileExtension === 'csv') {
                Papa.parse(selectedFile, {
                    header: true, skipEmptyLines: true,
                    complete: (results: any) => processParsedData(results.data, results.meta.fields),
                    error: () => { alert('Error parsing CSV file.'); setIsParsing(false); }
                });
            } else if (fileExtension === 'xlsx' || fileExtension === 'xls') {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const data = e.target?.result;
                        const workbook = XLSX.read(data, { type: 'array', cellDates: true });
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName];
                        const json = XLSX.utils.sheet_to_json(worksheet, {raw: false});
                        if (json.length > 0) {
                            processParsedData(json, Object.keys(json[0] as any));
                        } else {
                            alert("Excel file appears to be empty."); setIsParsing(false);
                        }
                    } catch (error) {
                         alert('Error parsing Excel file.'); setIsParsing(false);
                    }
                };
                reader.readAsArrayBuffer(selectedFile);
            } else {
                alert('Unsupported file type. Please upload a CSV or Excel file.');
                setIsParsing(false);
            }
        }
    };
    
    const handleMappingChange = (crmField: string, fileHeader: string) => {
        setMapping(prev => ({...prev, [crmField]: fileHeader }));
    }
    
    const handleMappingNext = () => {
        const initialPreview = parsedData.map((row, index) => {
            const mappedRow: { [key: string]: any } = { __id: index }; // Internal ID for stable rendering
            for (const crmField in mapping) {
                if (mapping[crmField]) {
                    mappedRow[crmField] = row[mapping[crmField]];
                }
            }
            return mappedRow;
        });
        setEditablePreviewData(initialPreview);
        setStep(3);
    };
    
    const handlePreviewEdit = (index: number, field: string, value: any) => {
        setEditablePreviewData(prev => {
            const newData = [...prev];
            const originalIndex = newData.findIndex(d => d.__id === index);
            if (originalIndex > -1) {
                newData[originalIndex][field] = value;
            }
            return newData;
        });
    };

    const validatedData = useMemo(() => {
        return editablePreviewData.map(row => {
            const validation: { [key: string]: string } = {};
            let hasError = false;

            REQUIRED_FIELDS.forEach(field => {
                const value = row[field];
                if (value === undefined || value === null || value === '') {
                    validation[field] = 'Required field is missing.';
                    hasError = true;
                } else if (field === 'totalPrice' && (isNaN(parseFloat(value)) || parseFloat(value) < 0)) {
                    validation[field] = 'Must be a valid non-negative number.';
                    hasError = true;
                }
            });

            const roomName = row['roomName'];
            if (roomName && !roomNames.has(roomName.toString().toLowerCase())) {
                validation['roomName'] = `Room "${roomName}" does not exist.`;
                hasError = true;
            }
            
            const checkIn = parseDate(row['checkIn']);
            const checkOut = parseDate(row['checkOut']);
            if(!row['checkIn'] || !row['checkOut'] || !checkIn || !checkOut) {
                validation['checkIn'] = 'Invalid date format.'; hasError = true;
            } else if (checkIn > checkOut) {
                validation['checkOut'] = 'Check-out cannot be before check-in.'; hasError = true;
            }
            
            return { data: row, validation, hasError };
        });
    }, [editablePreviewData, roomNames]);
    
    const filteredAndValidatedData = useMemo(() => {
        return showOnlyErrors ? validatedData.filter(item => item.hasError) : validatedData;
    }, [validatedData, showOnlyErrors]);

    const hasErrors = useMemo(() => validatedData.some(item => item.hasError), [validatedData]);

    const handleImport = () => {
        if (hasErrors) {
            alert("Please fix all errors before importing."); return;
        }

        const dataToImport = editablePreviewData.map(row => {
            const {__id, ...rest} = row;
            return rest;
        });

        onImportBookings(dataToImport);
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Import Bookings</h2>
            
            <div className="bg-white p-4 rounded-xl shadow-sm">
                <nav className="flex items-center justify-around">
                    {WIZARD_STEPS.map((s, index) => (
                        <React.Fragment key={s.number}>
                             <div className={`flex items-center ${step >= s.number ? 'text-brand-primary' : 'text-gray-400'}`}>
                                <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold ${step >= s.number ? 'border-brand-primary' : 'border-gray-400'}`}>
                                    {s.number}
                                </div>
                                <span className="ml-2 font-semibold hidden md:inline">{s.title}</span>
                            </div>
                            {index < WIZARD_STEPS.length - 1 && <div className="flex-grow h-px bg-gray-300 mx-4" />}
                        </React.Fragment>
                    ))}
                </nav>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm min-h-[400px]">
                {step === 1 && (
                    <div className="text-center">
                        <h3 className="text-lg font-semibold mb-2">Upload your file</h3>
                        <p className="text-gray-500 mb-4">File must contain headers. Required columns: {REQUIRED_FIELDS.join(', ')}.</p>
                        <div className="mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10">
                            {isParsing ? (
                                <div className="text-center">
                                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto"></div>
                                    <p className="mt-4 text-sm text-gray-600">Parsing your file...</p>
                                </div>
                            ) : (
                                <div className="text-center">
                                    <svg className="mx-auto h-12 w-12 text-gray-300" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path fillRule="evenodd" d="M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z" clipRule="evenodd" /></svg>
                                    <div className="mt-4 flex text-sm leading-6 text-gray-600">
                                        <label htmlFor="file-upload" className="relative cursor-pointer rounded-md bg-white font-semibold text-brand-primary focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-primary focus-within:ring-offset-2 hover:text-brand-dark">
                                            <span>Upload a file</span>
                                            <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept=".csv,.xlsx,.xls"/>
                                        </label>
                                        <p className="pl-1">or drag and drop</p>
                                    </div>
                                    <p className="text-xs leading-5 text-gray-600">CSV, XLS, XLSX up to 10MB</p>
                                    {fileName && <p className="text-sm text-green-600 mt-2 font-semibold">File selected: {fileName}</p>}
                                </div>
                            )}
                        </div>
                    </div>
                )}
                {step === 2 && (
                    <div>
                         <h3 className="text-lg font-semibold">Map your columns to CRM fields</h3>
                         <p className="text-sm text-gray-500 mb-4">We've automatically matched columns. Please review and make any necessary changes.</p>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                             <div>
                                <h4 className="font-bold text-gray-600 mb-2">Required Fields</h4>
                                {REQUIRED_FIELDS.map(field => (
                                    <div key={field} className="grid grid-cols-2 gap-4 items-center mb-2">
                                        <label className="font-medium text-gray-700 text-right">{field} <span className="text-red-500">*</span></label>
                                        <select value={mapping[field] || ''} onChange={e => handleMappingChange(field, e.target.value)} className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm">
                                            <option value="">Select a column...</option>
                                            {headers.map(h => <option key={h} value={h}>{h}</option>)}
                                        </select>
                                    </div>
                                ))}
                             </div>
                              <div>
                                <h4 className="font-bold text-gray-600 mb-2">Optional Fields</h4>
                                {OPTIONAL_FIELDS.map(field => (
                                    <div key={field} className="grid grid-cols-2 gap-4 items-center mb-2">
                                        <label className="font-medium text-gray-700 text-right">{field}</label>
                                        <select value={mapping[field] || ''} onChange={e => handleMappingChange(field, e.target.value)} className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm">
                                            <option value="">Select a column...</option>
                                            {headers.map(h => <option key={h} value={h}>{h}</option>)}
                                        </select>
                                    </div>
                                ))}
                             </div>
                         </div>
                         <div className="flex justify-end mt-6">
                            <button onClick={handleMappingNext} className="px-6 py-2 bg-brand-primary text-white font-semibold rounded-md hover:bg-brand-dark" disabled={REQUIRED_FIELDS.some(f => !mapping[f])}>
                                Next: Preview
                            </button>
                         </div>
                    </div>
                )}
                {step === 3 && (
                     <div>
                        <div className="flex justify-between items-center mb-4">
                            <div>
                                <h3 className="text-lg font-semibold">Preview and Confirm Import</h3>
                                <p className="text-sm text-gray-500">Review and edit your data before importing.</p>
                            </div>
                            <div className="flex items-center">
                                <input type="checkbox" id="show-errors" checked={showOnlyErrors} onChange={e => setShowOnlyErrors(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-brand-primary focus:ring-brand-primary" />
                                <label htmlFor="show-errors" className="ml-2 text-sm font-medium text-gray-700">Show only errors</label>
                            </div>
                        </div>
                        <div className="overflow-x-auto max-h-[50vh] border rounded-lg">
                            <table className="min-w-full text-sm">
                                <thead className="bg-gray-100 sticky top-0 z-10">
                                    <tr>
                                        {ALL_FIELDS.filter(f => mapping[f]).map(field => <th key={field} className="p-2 text-left font-semibold">{field}</th>)}
                                        <th className="p-2 text-left font-semibold">Validation</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {filteredAndValidatedData.map(({ data, validation, hasError }) => (
                                        <tr key={data.__id} className={hasError ? 'bg-red-50' : ''}>
                                            {ALL_FIELDS.filter(f => mapping[f]).map(field => (
                                                <td key={field} className="p-1 align-top">
                                                    <input 
                                                        type={field.includes('Date') ? 'date' : (field === 'totalPrice' ? 'number' : 'text')}
                                                        value={field.includes('Date') && data[field] ? new Date(data[field]).toISOString().split('T')[0] : data[field] || ''}
                                                        onChange={(e) => handlePreviewEdit(data.__id, field, e.target.value)}
                                                        className={`w-full p-1 rounded bg-transparent focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-primary ${validation[field] ? 'border border-red-400' : 'border border-transparent'}`}
                                                    />
                                                </td>
                                            ))}
                                            <td className="p-2 align-top">
                                                {hasError ? 
                                                    Object.entries(validation).map(([field, msg]) => <p key={field} className="text-red-600 text-xs"><strong>{field}:</strong> {msg}</p>)
                                                    : <span className="text-green-600 font-semibold text-xs">OK</span>
                                                }
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                         <div className="flex justify-between items-center mt-6">
                             <button onClick={() => setStep(2)} className="px-6 py-2 bg-gray-200 text-gray-800 rounded-md font-semibold hover:bg-gray-300">Back to Mapping</button>
                            <button onClick={handleImport} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed" disabled={hasErrors}>
                                {hasErrors ? 'Please fix errors' : `Confirm & Import ${validatedData.length} Bookings`}
                            </button>
                         </div>
                    </div>
                )}
            </div>
        </div>
    );
};