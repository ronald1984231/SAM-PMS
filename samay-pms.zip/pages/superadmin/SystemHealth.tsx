
import React from 'react';
import { SystemLog } from '../../types';

const getLevelChip = (level: 'INFO' | 'WARN' | 'ERROR'): { text: string; color: string } => {
    switch (level) {
        case 'INFO': return { text: 'INFO', color: 'bg-blue-500 text-white' };
        case 'WARN': return { text: 'WARN', color: 'bg-yellow-500 text-black' };
        case 'ERROR': return { text: 'ERROR', color: 'bg-red-500 text-white' };
    }
};

interface SystemHealthProps {
    systemLogs: SystemLog[];
}

export const SystemHealth: React.FC<SystemHealthProps> = ({ systemLogs }) => {
    return (
        <div className="bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-700">
            <h3 className="text-xl font-semibold text-white mb-4">System Health & Logs</h3>
            <p className="text-gray-400 mb-6">
                Monitor real-time system events, errors, and warnings from platform services.
            </p>
            <div className="overflow-x-auto">
                <table className="min-w-full">
                    <thead className="bg-gray-700">
                        <tr>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Timestamp</th>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Level</th>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Service</th>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Message</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-700">
                        {systemLogs.map((log) => {
                            const levelChip = getLevelChip(log.level);
                            return (
                                <tr key={log.id} className="hover:bg-gray-700">
                                    <td className="whitespace-nowrap py-3 px-4 text-sm text-gray-400 font-mono">
                                        {new Date(log.timestamp).toLocaleString()}
                                    </td>
                                    <td className="whitespace-nowrap py-3 px-4 text-sm">
                                         <span className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ${levelChip.color}`}>
                                            {levelChip.text}
                                        </span>
                                    </td>
                                    <td className="whitespace-nowrap py-3 px-4 text-sm text-gray-300 font-semibold">{log.service}</td>
                                    <td className="py-3 px-4 text-sm text-gray-300 font-mono">{log.message}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
