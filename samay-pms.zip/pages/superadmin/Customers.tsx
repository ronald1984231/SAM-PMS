
import React, { useMemo } from 'react';
import { SaaS_Customer, Property } from '../../types';
import { mockSubscriptionPlans } from '../../data/mockData';
import { ActionButtons } from '../../components/ActionButtons';

const getStatusChip = (status: 'Active' | 'Trial' | 'Cancelled'): { text: string; color: string } => {
    switch (status) {
        case 'Active': return { text: 'Active', color: 'bg-green-500 text-white' };
        case 'Trial': return { text: 'Trial', color: 'bg-yellow-500 text-black' };
        case 'Cancelled': return { text: 'Cancelled', color: 'bg-red-500 text-white' };
    }
};

interface CustomersProps {
    customers: SaaS_Customer[];
    properties: Property[];
}

export const Customers: React.FC<CustomersProps> = ({ customers, properties }) => {

    const customerData = useMemo(() => {
        const planMap = new Map(mockSubscriptionPlans.map(p => [p.name.toLowerCase(), p]));

        return customers.map(customer => {
            const propertyCount = properties.filter(p => p.customerId === customer.id).length;
            const plan = planMap.get(customer.subscriptionPlanId);
            return {
                ...customer,
                propertyCount,
                planName: plan?.name || 'N/A',
                mrr: customer.status === 'Active' ? plan?.monthlyRate || 0 : 0
            };
        });
    }, [customers, properties]);

    return (
        <div className="bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-700">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">Customer Management</h3>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-semibold">Add New Customer</button>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full">
                    <thead className="bg-gray-700">
                        <tr>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Customer Name</th>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Status</th>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Plan</th>
                            <th className="py-3 px-4 text-center text-sm font-semibold text-gray-300">Properties</th>
                            <th className="py-3 px-4 text-right text-sm font-semibold text-gray-300">MRR</th>
                            <th className="py-3 px-4 text-left text-sm font-semibold text-gray-300">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-700">
                        {customerData.map((customer) => {
                            const statusChip = getStatusChip(customer.status);
                            return (
                                <tr key={customer.id} className="hover:bg-gray-700">
                                    <td className="whitespace-nowrap py-4 px-4 text-sm font-medium text-white">{customer.name}</td>
                                    <td className="whitespace-nowrap py-4 px-4 text-sm">
                                         <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${statusChip.color}`}>
                                            {statusChip.text}
                                        </span>
                                    </td>
                                    <td className="whitespace-nowrap py-4 px-4 text-sm text-gray-300">{customer.planName}</td>
                                    <td className="whitespace-nowrap py-4 px-4 text-sm text-center text-gray-300">{customer.propertyCount}</td>
                                    <td className="whitespace-nowrap py-4 px-4 text-sm text-right text-gray-300">${customer.mrr.toFixed(2)}</td>
                                    <td className="whitespace-nowrap py-4 px-4 text-sm">
                                        <ActionButtons 
                                            onView={() => alert(`Viewing ${customer.name}`)}
                                            onEdit={() => alert(`Editing ${customer.name}`)}
                                            onDelete={() => alert(`Deleting ${customer.name}`)}
                                            isSuperAdmin={true}
                                        />
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};