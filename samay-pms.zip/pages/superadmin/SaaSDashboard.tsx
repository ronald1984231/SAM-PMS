
import React, { useMemo } from 'react';
import { SaaS_Customer, Property, User, SubscriptionPlan } from '../../types';
import { mockSubscriptionPlans } from '../../data/mockData';

const AdminKPICard: React.FC<{ title: string; value: string | number; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-700 flex items-center space-x-6">
        <div className="p-4 rounded-full bg-blue-600 text-white">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-gray-400">{title}</p>
            <p className="text-3xl font-bold text-white">{value}</p>
        </div>
    </div>
);

const CustomersIcon: React.FC<{className?: string}> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>;
const PropertiesIcon: React.FC<{className?: string}> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>;
const RevenueIcon: React.FC<{className?: string}> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01M12 6v-1.667a1.667 1.667 0 01.958-1.528l1.306-.755a1.667 1.667 0 012.172 1.528V6m-4.436-1.857A1.667 1.667 0 009.638 3.5H7.362a1.667 1.667 0 00-1.436 2.387l1.306.755A1.667 1.667 0 009 6.5V7m0-1h3m-3 4h3m-3 4h3m0 4v-1.667a1.667 1.667 0 00-.958-1.528l-1.306-.755a1.667 1.667 0 00-2.172 1.528V18m4.436 1.857A1.667 1.667 0 0114.362 20.5h2.276a1.667 1.667 0 011.436-2.387l-1.306-.755a1.667 1.667 0 01-2.172-1.528V15m-3 4.5v.01" /></svg>;
const UsersIcon: React.FC<{className?: string}> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.225-1.264-.62-1.751M17 20h-2M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.225-1.264.62-1.751M7 20h2m-4 0v-2c0-1.105.895-2 2-2h12a2 2 0 012 2v2M9 4a3 3 0 11-6 0 3 3 0 016 0zm12 0a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;

interface SaaSDashboardProps {
    customers: SaaS_Customer[];
    properties: Property[];
    users: User[];
}

export const SaaSDashboard: React.FC<SaaSDashboardProps> = ({ customers, properties, users }) => {

    const stats = useMemo(() => {
        const totalCustomers = customers.length;
        const totalProperties = properties.length;
        const activeUsers = users.length; // Simplified for demo

        const mrr = customers.reduce((acc, customer) => {
            if (customer.status === 'Active') {
                const plan = mockSubscriptionPlans.find(p => p.name.toLowerCase() === customer.subscriptionPlanId);
                return acc + (plan?.monthlyRate || 0);
            }
            return acc;
        }, 0);

        return { totalCustomers, totalProperties, activeUsers, mrr };
    }, [customers, properties, users]);

    return (
        <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-white">SaaS Platform Overview</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <AdminKPICard title="Total Customers" value={stats.totalCustomers} icon={<CustomersIcon className="h-8 w-8" />} />
                <AdminKPICard title="Total Properties" value={stats.totalProperties} icon={<PropertiesIcon className="h-8 w-8" />} />
                <AdminKPICard title="Monthly Recurring Revenue" value={`$${stats.mrr.toLocaleString()}`} icon={<RevenueIcon className="h-8 w-8" />} />
                <AdminKPICard title="Active Users" value={stats.activeUsers} icon={<UsersIcon className="h-8 w-8" />} />
            </div>

            <div className="bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-700">
                 <h3 className="text-xl font-semibold text-white mb-4">Recent Activity</h3>
                 <p className="text-gray-400">Activity feed would be shown here...</p>
                 {/* Placeholder for future activity feed */}
            </div>
        </div>
    );
};
