import React, { useState } from 'react';
import { Guest, Booking, BookingStatus } from '../types';
import { GuestModal } from '../components/GuestModal';
import { ActionButtons } from '../components/ActionButtons';

interface GuestsProps {
    guests: Guest[];
    bookings: Booking[];
    onSaveGuest: (guest: Omit<Guest, 'id'> & { id?: string }) => void;
    onDeleteGuest: (guestId: string) => void;
}

const getGuestStatus = (guestId: string, bookings: Booking[]): { text: string; color: string } => {
    const guestBookings = bookings.filter(b => b.guestId === guestId);
    if (guestBookings.some(b => b.status === BookingStatus.CheckedIn)) {
        return { text: 'In House', color: 'bg-green-100 text-green-800' };
    }
    const today = new Date().toISOString().split('T')[0];
    if (guestBookings.some(b => b.status === BookingStatus.Confirmed && b.checkIn >= today)) {
        return { text: 'Upcoming', color: 'bg-blue-100 text-blue-800' };
    }
    if (guestBookings.length > 0) {
        return { text: 'Past Guest', color: 'bg-gray-100 text-gray-800' };
    }
    return { text: 'No Bookings', color: 'bg-yellow-100 text-yellow-800' };
};

export const Guests: React.FC<GuestsProps> = ({ guests, bookings, onSaveGuest, onDeleteGuest }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);

    const handleOpenModal = (guest: Guest | null) => {
        setSelectedGuest(guest);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedGuest(null);
    };

    const handleSave = (guest: Omit<Guest, 'id'> & { id?: string }) => {
        onSaveGuest(guest);
        handleCloseModal();
    };

    const handleDelete = (guestId: string) => {
        if(window.confirm(`Are you sure you want to delete this guest? This will also remove their bookings.`)) {
            onDeleteGuest(guestId);
        }
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-gray-800">Guest Directory</h3>
                <button onClick={() => handleOpenModal(null)} className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary font-semibold">
                    Create New Guest
                </button>
            </div>
            <div className="overflow-x-auto">
                 {guests.length > 0 ? (
                    <table className="min-w-full bg-white">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Name</th>
                                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Contact</th>
                                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Status</th>
                                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-gray-900">Total Bookings</th>
                                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {guests.map((guest) => {
                                const guestStatus = getGuestStatus(guest.id, bookings);
                                const totalBookings = bookings.filter(b => b.guestId === guest.id).length;
                                return (
                                    <tr key={guest.id} className="hover:bg-gray-50">
                                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm sm:pl-6">
                                            <div className="flex items-center">
                                                <div className="h-10 w-10 flex-shrink-0">
                                                    <img className="h-10 w-10 rounded-full" src={`https://i.pravatar.cc/150?u=${guest.id}`} alt="" />
                                                </div>
                                                <div className="ml-4">
                                                    <div className="font-medium text-gray-900">{guest.name}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                            <div className="text-gray-900">{guest.email}</div>
                                            <div className="text-gray-500">{guest.phone}</div>
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                            <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${guestStatus.color}`}>
                                                {guestStatus.text}
                                            </span>
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-center text-gray-500">{totalBookings}</td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                           <ActionButtons
                                                onView={() => handleOpenModal(guest)}
                                                onEdit={() => handleOpenModal(guest)}
                                                onDelete={() => handleDelete(guest.id)}
                                            />
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                 ) : (
                    <div className="text-center py-16 border-2 border-dashed rounded-lg">
                        <h4 className="mt-4 text-lg font-semibold text-gray-800">No Guests Found</h4>
                        <p className="text-gray-500 mt-1">Get started by creating a new guest or importing data.</p>
                    </div>
                 )}
            </div>
            {isModalOpen && (
                <GuestModal 
                    isOpen={isModalOpen}
                    onClose={handleCloseModal}
                    onSave={handleSave}
                    guest={selectedGuest}
                />
            )}
        </div>
    );
};