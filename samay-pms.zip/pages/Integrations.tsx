
import React from 'react';
import { Integration, IntegrationCategory } from '../types';

interface ToggleSwitchProps {
    checked: boolean;
    onChange: (checked: boolean) => void;
}

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ checked, onChange }) => (
    <button
        type="button"
        className={`${
            checked ? 'bg-brand-primary' : 'bg-gray-200'
        } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-offset-2`}
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
    >
        <span
            aria-hidden="true"
            className={`${
                checked ? 'translate-x-5' : 'translate-x-0'
            } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
        />
    </button>
);


interface IntegrationCardProps {
    integration: Integration;
    onToggle: (id: string, connected: boolean) => void;
}

const IntegrationCard: React.FC<IntegrationCardProps> = ({ integration, onToggle }) => {
    return (
        <div className="bg-white rounded-xl shadow-md p-6 flex flex-col justify-between hover:shadow-lg transition-shadow duration-300">
            <div>
                <div className="flex items-center justify-between mb-4">
                    <img src={integration.logoUrl} alt={`${integration.name} logo`} className="h-10 w-auto"/>
                    <ToggleSwitch checked={integration.connected} onChange={(checked) => onToggle(integration.id, checked)} />
                </div>
                <h4 className="text-lg font-bold text-gray-800">{integration.name}</h4>
                <p className="text-sm text-gray-500 mt-1">{integration.category}</p>
                <p className="text-sm text-gray-600 mt-3 h-16">{integration.description}</p>
            </div>
            <div className="mt-4">
                <span className={`px-3 py-1 text-xs font-semibold rounded-full ${integration.connected ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                    {integration.connected ? 'Connected' : 'Disconnected'}
                </span>
            </div>
        </div>
    );
};

interface IntegrationsProps {
    integrations: Integration[];
    onToggleIntegration: (id: string, connected: boolean) => void;
}

export const Integrations: React.FC<IntegrationsProps> = ({ integrations, onToggleIntegration }) => {
    const categories = Object.values(IntegrationCategory);

    return (
        <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-gray-800">Connect Your Tools</h3>
            <p className="text-gray-600 mt-2">
                Automate your workflows by connecting Horizon PMS with your favorite apps.
            </p>
            
            {categories.map(category => {
                const filteredIntegrations = integrations.filter(int => int.category === category);
                if(filteredIntegrations.length === 0) return null;

                return (
                    <div key={category}>
                        <h4 className="text-xl font-semibold text-gray-700 mb-4 pb-2 border-b">{category}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {filteredIntegrations.map(integration => (
                                <IntegrationCard
                                    key={integration.id}
                                    integration={integration}
                                    onToggle={onToggleIntegration}
                                />
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
    );
};
