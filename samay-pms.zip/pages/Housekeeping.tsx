
import React, { useMemo, useState, ChangeEvent } from 'react';
import { Room, HousekeepingStatus, Booking, Guest, BookingStatus, RoomType } from '../types';

const housekeepingStatusConfig: { [key in HousekeepingStatus]: { color: string; text: string; } } = {
    [HousekeepingStatus.Clean]: { color: 'bg-green-100 text-green-800', text: 'Clean' },
    [HousekeepingStatus.InProgress]: { color: 'bg-blue-100 text-blue-800', text: 'In Progress' },
    [HousekeepingStatus.Dirty]: { color: 'bg-yellow-100 text-yellow-800', text: 'Dirty' },
    [HousekeepingStatus.Inspection]: { color: 'bg-purple-100 text-purple-800', text: 'Inspection' },
};

const roomTypeLabels: { [key in RoomType]: string } = {
    [RoomType.Single]: 'Single',
    [RoomType.Double]: 'Double',
    [RoomType.Suite]: 'Suite',
};

const availabilityStatusConfig = {
    'Vacant': { color: 'text-green-600', text: 'Vacant' },
    'Stay Over': { color: 'text-blue-600', text: 'Stay Over' },
    'Due Out': { color: 'text-red-600', text: 'Due Out' },
    'Arrived': { color: 'text-green-800', text: 'Arrived' },
};

interface HousekeepingProps {
    rooms: Room[];
    bookings: Booking[];
    guests: Guest[];
    onUpdateRoom: (room: Room) => void;
}

export const Housekeeping: React.FC<HousekeepingProps> = ({ rooms, bookings, guests, onUpdateRoom }) => {
    
    const [filters, setFilters] = useState({
        roomType: 'ALL',
        status: 'ALL',
        availability: 'ALL'
    });
    
    const [remarks, setRemarks] = useState<Record<string, {fo: string, hk: string}>>({});

    const handleFilterChange = (e: ChangeEvent<HTMLSelectElement>) => {
        setFilters(prev => ({...prev, [e.target.name]: e.target.value}));
    }

    const handleRemarkChange = (roomId: string, type: 'fo' | 'hk', value: string) => {
        setRemarks(prev => ({...prev, [roomId]: {...(prev[roomId] || {fo:'', hk:''}), [type]: value}}));
    };

    const handleRemarkBlur = (room: Room, type: 'fo' | 'hk') => {
        const newRemark = remarks[room.id]?.[type];
        if (newRemark !== undefined && newRemark !== room[type === 'fo' ? 'foRemarks' : 'hkRemarks']) {
             onUpdateRoom({ ...room, [type === 'fo' ? 'foRemarks' : 'hkRemarks']: newRemark });
        }
    };

    const handleStatusChange = (room: Room, newStatus: HousekeepingStatus) => {
        onUpdateRoom({ ...room, housekeepingStatus: newStatus });
    };

    const enhancedRoomData = useMemo(() => {
        const todayStr = new Date().toISOString().split('T')[0];
        
        return rooms.map(room => {
            let availability: keyof typeof availabilityStatusConfig = 'Vacant';
            
            const checkedInBooking = bookings.find(b => b.roomId === room.id && b.status === BookingStatus.CheckedIn);
            const arrivingBooking = bookings.find(b => b.roomId === room.id && b.checkIn === todayStr && b.status === BookingStatus.Confirmed);

            if (checkedInBooking) {
                availability = checkedInBooking.checkOut === todayStr ? 'Due Out' : 'Stay Over';
            } else if (arrivingBooking) {
                availability = 'Arrived';
            }
            
            return {
                ...room,
                availability
            };
        }).filter(room => {
            if (filters.roomType !== 'ALL' && room.type !== filters.roomType) return false;
            if (filters.status !== 'ALL' && room.housekeepingStatus !== filters.status) return false;
            if (filters.availability !== 'ALL' && room.availability !== filters.availability) return false;
            return true;
        });

    }, [rooms, bookings, filters]);

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h3 className="text-2xl font-semibold text-gray-800 mb-4">Daily Status</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-4 p-4 bg-gray-50 rounded-lg">
                <select name="roomType" value={filters.roomType} onChange={handleFilterChange} className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm">
                    <option value="ALL">All House Type</option>
                    {Object.values(RoomType).map(rt => <option key={rt} value={rt}>{roomTypeLabels[rt]}</option>)}
                </select>
                <select name="status" value={filters.status} onChange={handleFilterChange} className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm">
                    <option value="ALL">All Status</option>
                     {Object.values(HousekeepingStatus).map(s => <option key={s} value={s}>{housekeepingStatusConfig[s].text}</option>)}
                </select>
                <select name="availability" value={filters.availability} onChange={handleFilterChange} className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm">
                    <option value="ALL">All Availability</option>
                     {Object.keys(availabilityStatusConfig).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white text-sm">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">Room/Unit</th>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">Room Type</th>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">Status</th>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">Availability</th>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">FO Remarks</th>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">HK Remarks</th>
                            <th className="py-2 px-3 text-left font-semibold text-gray-600">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {enhancedRoomData.map(room => (
                            <tr key={room.id} className="hover:bg-gray-50">
                                <td className="py-2 px-3 font-bold text-gray-800">{room.name}</td>
                                <td className="py-2 px-3">{roomTypeLabels[room.type]}</td>
                                <td className="py-2 px-3">
                                    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${housekeepingStatusConfig[room.housekeepingStatus].color}`}>
                                        {housekeepingStatusConfig[room.housekeepingStatus].text}
                                    </span>
                                </td>
                                <td className={`py-2 px-3 font-semibold ${availabilityStatusConfig[room.availability].color}`}>
                                    {availabilityStatusConfig[room.availability].text}
                                </td>
                                <td className="py-2 px-3">
                                    <input 
                                        type="text"
                                        value={remarks[room.id]?.fo ?? room.foRemarks ?? ''}
                                        onChange={(e) => handleRemarkChange(room.id, 'fo', e.target.value)}
                                        onBlur={() => handleRemarkBlur(room, 'fo')}
                                        className="w-full bg-transparent outline-none focus:bg-yellow-100 rounded p-1"
                                    />
                                </td>
                                <td className="py-2 px-3">
                                     <input 
                                        type="text"
                                        value={remarks[room.id]?.hk ?? room.hkRemarks ?? ''}
                                        onChange={(e) => handleRemarkChange(room.id, 'hk', e.target.value)}
                                        onBlur={() => handleRemarkBlur(room, 'hk')}
                                        className="w-full bg-transparent outline-none focus:bg-yellow-100 rounded p-1"
                                    />
                                </td>
                                 <td className="py-2 px-3">
                                    <select 
                                        value={room.housekeepingStatus} 
                                        onChange={(e) => handleStatusChange(room, e.target.value as HousekeepingStatus)}
                                        className="px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary text-xs"
                                    >
                                        {Object.values(HousekeepingStatus).map(s => (
                                            <option key={s} value={s}>{housekeepingStatusConfig[s].text}</option>
                                        ))}
                                    </select>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
