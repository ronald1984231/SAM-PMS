
import React, { useState, useMemo } from 'react';
import { Room, Booking, Guest, BookingStatus, PaymentMode, PaymentAccount, PlatformSettings, Property } from '../types';
import { BookingWizardModal } from '../components/BookingWizardModal';
import { BookingModal } from '../components/BookingModal';
import { BookingsListHeader } from '../components/BookingsListHeader';
import { BookingCard } from '../components/BookingCard';

interface BookingsProps {
    rooms: Room[];
    bookings: Booking[];
    guests: Guest[];
    onSaveBooking: (booking: Omit<Booking, 'id'> & { id?: string }) => void;
    onDeleteBooking: (bookingId: string) => void;
    onSaveGuest: (guest: Omit<Guest, 'id'> & { id?: string }) => Guest;
    propertyId: string;
    paymentModes: PaymentMode[];
    paymentAccounts: PaymentAccount[];
    platformSettings: PlatformSettings;
    selectedProperty: Property;
}

export const Bookings: React.FC<BookingsProps> = ({ rooms, bookings, guests, onSaveBooking, onDeleteBooking, onSaveGuest, propertyId, paymentModes, paymentAccounts, platformSettings, selectedProperty }) => {
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [isWizardOpen, setIsWizardOpen] = useState(false);
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState<BookingStatus | 'ALL'>('ALL');
    
    const guestMap = useMemo(() => new Map(guests.map(g => [g.id, g])), [guests]);

    const filteredBookings = useMemo(() => {
        return bookings
            .filter(b => {
                const guestName = guestMap.get(b.guestId)?.name || '';
                const guestPhone = guestMap.get(b.guestId)?.phone || '';
                return guestName.toLowerCase().includes(searchTerm.toLowerCase()) || guestPhone.includes(searchTerm);
            })
            .filter(b => statusFilter === 'ALL' || b.status === statusFilter)
            .sort((a, b) => new Date(b.checkIn).getTime() - new Date(a.checkIn).getTime());
    }, [bookings, searchTerm, statusFilter, guestMap]);


    const handleEditBooking = (booking: Booking) => {
        setSelectedBooking(booking);
        setIsEditModalOpen(true);
    };
    
    const handleDeleteBookingLocal = (bookingId: string) => {
        if(window.confirm('Are you sure you want to delete this booking permanently?')) {
            onDeleteBooking(bookingId);
        }
    };

    const handleSave = (bookingToSave: Omit<Booking, 'id'> & { id?: string }) => {
        onSaveBooking(bookingToSave);
        setIsEditModalOpen(false);
        setIsWizardOpen(false);
    };

    return (
        <div className="space-y-6">
            <div className="bg-white p-4 rounded-xl shadow-sm">
                 <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-gray-800">Reservations</h3>
                     <button onClick={() => setIsWizardOpen(true)} className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary font-semibold flex items-center shadow-sm">
                        New Reservation
                    </button>
                </div>
                <div className="flex flex-wrap items-center gap-4">
                     <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value as BookingStatus | 'ALL')}
                        className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm bg-white"
                    >
                        <option value="ALL">All Statuses</option>
                        {Object.values(BookingStatus).map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                    </select>
                    <input
                        type="text"
                        placeholder="Search by guest name or phone..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="flex-grow px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm"
                    />
                </div>
            </div>

            <div className="space-y-2">
                <BookingsListHeader />
                {filteredBookings.map((booking) => (
                    <BookingCard
                        key={booking.id}
                        booking={booking}
                        guest={guestMap.get(booking.guestId)}
                        room={rooms.find(r => r.id === booking.roomId)}
                        onView={() => handleEditBooking(booking)}
                        onEdit={() => handleEditBooking(booking)}
                        onDelete={() => handleDeleteBookingLocal(booking.id)}
                        platformSettings={platformSettings}
                        isOyoManaged={selectedProperty.managementType === 'OYO'}
                    />
                ))}
                 {filteredBookings.length === 0 && (
                    <div className="text-center py-10 bg-white rounded-lg shadow">
                        <p className="text-gray-500">No bookings match your search criteria.</p>
                    </div>
                )}
            </div>

            {isEditModalOpen && (
                 <BookingModal
                    isOpen={isEditModalOpen}
                    onClose={() => setIsEditModalOpen(false)}
                    onSave={handleSave}
                    booking={selectedBooking}
                    rooms={rooms}
                    guests={guests}
                    existingBookings={bookings}
                    propertyId={propertyId}
                    paymentModes={paymentModes}
                    paymentAccounts={paymentAccounts}
                    platformSettings={platformSettings}
                    propertyManagementType={selectedProperty.managementType}
                />
            )}
            
            {isWizardOpen && (
                <BookingWizardModal
                    isOpen={isWizardOpen}
                    onClose={() => setIsWizardOpen(false)}
                    onSaveBooking={handleSave}
                    onSaveGuest={onSaveGuest}
                    guests={guests}
                    rooms={rooms}
                    existingBookings={bookings}
                    propertyId={propertyId}
                    paymentModes={paymentModes}
                    paymentAccounts={paymentAccounts}
                    platformSettings={platformSettings}
                    propertyManagementType={selectedProperty.managementType}
                />
            )}
        </div>
    );
};