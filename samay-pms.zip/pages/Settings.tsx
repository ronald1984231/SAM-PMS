
import React, { useState, useEffect } from 'react';
import { PlatformSettings, User, PaymentMode, PaymentAccount, Integration, IntegrationCategory, AuditLog } from '../types';
import { ActionButtons } from '../components/ActionButtons';
import { UserModal } from '../components/UserModal';

// --- Components and helpers for Settings sub-pages ---

const INTEGRATION_FIELDS: { [key: string]: { name: string; label: string; type: 'text' | 'password' | 'select'; placeholder?: string; options?: string[] }[] } = {
    'Stripe': [
        { name: 'publishableKey', label: 'Publishable Key', type: 'text', placeholder: 'pk_test_...' },
        { name: 'secretKey', label: 'Secret Key', type: 'password', placeholder: 'sk_test_...' }
    ],
    'Booking.com': [
        { name: 'apiKey', label: 'API Key', type: 'password' },
        { name: 'hotelId', label: 'Hotel ID', type: 'text' }
    ],
    'Expedia': [
        { name: 'apiKey', label: 'API Key', type: 'password' },
        { name: 'hotelId', label: 'Hotel ID', type: 'text' }
    ],
    'QuickBooks': [
        { name: 'apiKey', label: 'API Key', type: 'password' }
    ],
    'Toast POS': [
        { name: 'apiKey', label: 'API Key', type: 'password' }
    ],
    'WhatsApp Business': [
        { name: 'apiToken', label: 'API Token', type: 'password' },
        { name: 'phoneNumberId', label: 'Phone Number ID', type: 'text' }
    ],
    'Twilio': [
        { name: 'accountSid', label: 'Account SID', type: 'text', placeholder: 'AC...' },
        { name: 'authToken', label: 'Auth Token', type: 'password' },
        { name: 'phoneNumber', label: 'Twilio Phone Number', type: 'text' }
    ],
    'Email Reports': [
        { name: 'recipients', label: 'Recipient Emails', type: 'text', placeholder: 'comma, separated, list' },
        { name: 'frequency', label: 'Frequency', type: 'select', options: ['Daily', 'Weekly', 'Monthly'] }
    ]
};

interface IntegrationSettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (integration: Integration) => void;
    integration: Integration | null;
}

const IntegrationSettingsModal: React.FC<IntegrationSettingsModalProps> = ({ isOpen, onClose, onSave, integration }) => {
    const [credentials, setCredentials] = useState<{ [key: string]: string }>({});

    useEffect(() => {
        if (integration) {
            setCredentials(integration.credentials || {});
        }
    }, [integration]);
    
    if (!isOpen || !integration) return null;

    const fields = INTEGRATION_FIELDS[integration.name] || [];
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setCredentials(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSave = () => {
        onSave({ ...integration, credentials, connected: true });
        onClose();
    };

    const handleDisconnect = () => {
        const clearedCredentials = Object.keys(integration.credentials || {}).reduce((acc, key) => ({ ...acc, [key]: '' }), {});
        onSave({ ...integration, credentials: clearedCredentials, connected: false });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold text-gray-800">Configure {integration.name}</h2>
                <div className="mt-6 space-y-4">
                    {fields.map(field => (
                        <div key={field.name}>
                            <label htmlFor={field.name} className="block text-sm font-medium text-gray-700">{field.label}</label>
                            {field.type === 'select' ? (
                                <select 
                                    id={field.name} 
                                    name={field.name}
                                    value={credentials[field.name] || ''}
                                    onChange={handleChange}
                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm"
                                >
                                    {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                </select>
                            ) : (
                                <input
                                    type={field.type}
                                    id={field.name}
                                    name={field.name}
                                    value={credentials[field.name] || ''}
                                    onChange={handleChange}
                                    placeholder={field.placeholder || ''}
                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm"
                                />
                            )}
                        </div>
                    ))}
                </div>
                <div className="flex justify-between items-center mt-8">
                    {integration.connected && (
                         <button type="button" onClick={handleDisconnect} className="text-red-600 font-semibold text-sm hover:text-red-800">Disconnect</button>
                    )}
                    {!integration.connected && <div/>}
                    <div className="flex space-x-3">
                        <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">Cancel</button>
                        <button type="button" onClick={handleSave} className="bg-brand-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Save Changes</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

interface IntegrationCardProps {
    integration: Integration;
    onManage: (integration: Integration) => void;
}

const IntegrationCard: React.FC<IntegrationCardProps> = ({ integration, onManage }) => {
    return (
        <div className="bg-gray-50 rounded-xl shadow-md p-6 flex flex-col justify-between hover:shadow-lg transition-shadow duration-300 border border-transparent hover:border-brand-light">
            <div>
                <div className="flex items-start justify-between mb-4">
                    <img src={integration.logoUrl} alt={`${integration.name} logo`} className="h-10 w-auto"/>
                    <div className="flex items-center space-x-2">
                         <div className={`w-3 h-3 rounded-full ${integration.connected ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                         <span className="text-xs font-semibold text-gray-500">{integration.connected ? 'Connected' : 'Disconnected'}</span>
                    </div>
                </div>
                <h4 className="text-lg font-bold text-gray-800">{integration.name}</h4>
                <p className="text-sm text-gray-500 mt-1">{integration.category}</p>
                <p className="text-sm text-gray-600 mt-3 h-16">{integration.description}</p>
            </div>
            <div className="mt-4">
                 <button 
                    onClick={() => onManage(integration)}
                    className={`w-full py-2 rounded-md font-semibold text-sm ${integration.connected ? 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100' : 'bg-brand-secondary text-white hover:bg-brand-dark'}`}
                 >
                    {integration.connected ? 'Manage' : 'Connect'}
                 </button>
            </div>
        </div>
    );
};


const getActionChip = (action: string): { text: string; color: string } => {
    switch (action) {
        case 'LOGIN':
            return { text: 'Login', color: 'bg-green-100 text-green-800' };
        case 'LOGIN_FAILED':
            return { text: 'Login Failed', color: 'bg-red-100 text-red-800' };
        case 'UPDATE_BOOKING':
        case 'CREATE_BOOKING':
            return { text: 'Booking', color: 'bg-blue-100 text-blue-800' };
        case 'UPDATE_HOUSEKEEPING':
            return { text: 'Housekeeping', color: 'bg-yellow-100 text-yellow-800' };
        case 'TOGGLE_INTEGRATION':
            return { text: 'Integration', color: 'bg-purple-100 text-purple-800' };
        default:
            return { text: 'System', color: 'bg-gray-100 text-gray-800' };
    }
};

interface EditableListItemProps {
    item: { id: string; name: string; details?: string };
    onSave: (item: { id: string; name: string; details?: string }) => void;
    onDelete: (id: string) => void;
}

const EditableListItem: React.FC<EditableListItemProps> = ({ item, onSave, onDelete }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [name, setName] = useState(item.name);
    const [details, setDetails] = useState(item.details || '');

    const handleSave = () => {
        onSave({ id: item.id, name, details });
        setIsEditing(false);
    };
    
    const handleDelete = () => {
        if(window.confirm(`Are you sure you want to delete "${item.name}"?`)){
            onDelete(item.id);
        }
    };

    return (
        <li className="bg-gray-100 p-2 rounded-md flex items-center justify-between">
            {isEditing ? (
                <div className="flex-grow flex gap-2">
                    <input type="text" value={name} onChange={e => setName(e.target.value)} className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"/>
                    {item.details !== undefined && (
                        <input type="text" value={details} onChange={e => setDetails(e.target.value)} className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"/>
                    )}
                </div>
            ) : (
                <span className="text-sm">
                    <strong>{item.name}</strong> {item.details && `(${item.details})`}
                </span>
            )}
            <div className="flex gap-2 ml-4">
                {isEditing ? (
                    <button onClick={handleSave} className="text-green-600 hover:text-green-800">Save</button>
                ) : (
                     <ActionButtons onEdit={() => setIsEditing(true)} onDelete={handleDelete} hideView/>
                )}
            </div>
        </li>
    );
};


interface SettingsProps {
    settings: PlatformSettings;
    onUpdateSettings: (newSettings: PlatformSettings) => void;
    users: User[];
    onSaveUser: (user: Omit<User, 'id'> & { id?: string }) => void;
    onDeleteUser: (userId: string) => void;
    paymentModes: PaymentMode[];
    onSavePaymentMode: (mode: PaymentMode) => void;
    onDeletePaymentMode: (id: string) => void;
    paymentAccounts: PaymentAccount[];
    onSavePaymentAccount: (account: PaymentAccount) => void;
    onDeletePaymentAccount: (id: string) => void;
    integrations: Integration[];
    onSaveIntegration: (integration: Integration) => void;
    auditLogs: AuditLog[];
}

type Tab = 'general' | 'payments' | 'users' | 'integrations' | 'security';

export const Settings: React.FC<SettingsProps> = (props) => {
    const { 
        settings, onUpdateSettings, 
        users, onSaveUser, onDeleteUser,
        paymentModes, onSavePaymentMode, onDeletePaymentMode,
        paymentAccounts, onSavePaymentAccount, onDeletePaymentAccount,
        integrations, onSaveIntegration,
        auditLogs
    } = props;
    
    const [activeTab, setActiveTab] = useState<Tab>('general');
    const [localSettings, setLocalSettings] = useState(settings);
    
    const [newModeName, setNewModeName] = useState('');
    const [newAccountName, setNewAccountName] = useState('');
    const [newAccountDetails, setNewAccountDetails] = useState('');
    
    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    
    const [isIntegrationModalOpen, setIsIntegrationModalOpen] = useState(false);
    const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);


    const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setLocalSettings(prev => ({ ...prev, [name]: value }));
    };
    
    const handleSaveSettings = () => {
        onUpdateSettings(localSettings);
        alert('Settings saved!');
    };
    
    const handleAddMode = (e: React.FormEvent) => {
        e.preventDefault();
        if(newModeName.trim()) {
            onSavePaymentMode({id: '', name: newModeName.trim()});
            setNewModeName('');
        }
    };
    
    const handleAddAccount = (e: React.FormEvent) => {
        e.preventDefault();
        if(newAccountName.trim() && newAccountDetails.trim()) {
            onSavePaymentAccount({ id: '', name: newAccountName.trim(), details: newAccountDetails.trim() });
            setNewAccountName('');
            setNewAccountDetails('');
        }
    };
    
    const handleEditUser = (user: User) => {
        setSelectedUser(user);
        setIsUserModalOpen(true);
    };

    const handleSaveUserModal = (user: Omit<User, 'id'> & { id?: string }) => {
        onSaveUser(user);
        setIsUserModalOpen(false);
        setSelectedUser(null);
    };
    
    const handleDeleteUserLocal = (userId: string) => {
        if(window.confirm('Are you sure you want to delete this user?')){
            onDeleteUser(userId);
        }
    };

    const handleManageIntegration = (integration: Integration) => {
        setSelectedIntegration(integration);
        setIsIntegrationModalOpen(true);
    };

    const TabButton: React.FC<{ tab: Tab, label: string }> = ({ tab, label }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === tab ? 'bg-brand-primary text-white shadow' : 'text-gray-600 hover:bg-gray-100'
            }`}
        >
            {label}
        </button>
    );

    const getUserName = (userId: string) => {
        return users.find(u => u.id === userId)?.name || 'System';
    };

    const integrationCategories = Object.values(IntegrationCategory);

    return (
        <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-gray-800">Platform Settings</h3>
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex flex-wrap gap-2 border-b border-gray-200 pb-4 mb-6">
                    <TabButton tab="general" label="General" />
                    <TabButton tab="payments" label="Payments" />
                    <TabButton tab="users" label="Users & Roles" />
                    <TabButton tab="integrations" label="Integrations" />
                    <TabButton tab="security" label="Security & Audit" />
                </div>
                
                {activeTab === 'general' && (
                    <div className="space-y-6 max-w-lg">
                        <h4 className="text-lg font-semibold text-gray-700">General Configuration</h4>
                         <div>
                            <label htmlFor="currency" className="block text-sm font-medium text-gray-700">Currency</label>
                            <select id="currency" name="currency" value={localSettings.currency} onChange={handleSettingsChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm rounded-md">
                                <option>USD</option>
                                <option>EUR</option>
                                <option>GBP</option>
                                <option>INR</option>
                                <option>JPY</option>
                            </select>
                        </div>
                         <div>
                            <label htmlFor="timezone" className="block text-sm font-medium text-gray-700">Timezone</label>
                            <select id="timezone" name="timezone" value={localSettings.timezone} onChange={handleSettingsChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm rounded-md">
                               <option>America/New_York</option>
                               <option>Europe/London</option>
                               <option>Asia/Kolkata</option>
                               <option>Asia/Tokyo</option>
                               <option>UTC</option>
                            </select>
                        </div>
                        <div className="pt-4">
                            <button onClick={handleSaveSettings} className="bg-brand-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">Save General Settings</button>
                        </div>
                    </div>
                )}
                
                {activeTab === 'payments' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                             <h4 className="text-lg font-semibold text-gray-700 mb-4">Payment Modes</h4>
                             <ul className="space-y-2 mb-4">
                                {paymentModes.map(mode => <EditableListItem key={mode.id} item={mode} onSave={(item) => onSavePaymentMode(item as PaymentMode)} onDelete={onDeletePaymentMode} />)}
                             </ul>
                             <form onSubmit={handleAddMode} className="flex space-x-2">
                                <input type="text" value={newModeName} onChange={e => setNewModeName(e.target.value)} placeholder="New mode name" className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"/>
                                <button type="submit" className="bg-blue-500 text-white font-semibold py-2 px-3 rounded-lg hover:bg-blue-600 text-sm">Add</button>
                             </form>
                        </div>
                        <div>
                             <h4 className="text-lg font-semibold text-gray-700 mb-4">Payment Accounts</h4>
                             <ul className="space-y-2 mb-4">
                                {paymentAccounts.map(acc => <EditableListItem key={acc.id} item={acc} onSave={(item) => onSavePaymentAccount(item as PaymentAccount)} onDelete={onDeletePaymentAccount} />)}
                             </ul>
                             <form onSubmit={handleAddAccount} className="space-y-2">
                                <input type="text" value={newAccountName} onChange={e => setNewAccountName(e.target.value)} placeholder="New account name" className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"/>
                                <input type="text" value={newAccountDetails} onChange={e => setNewAccountDetails(e.target.value)} placeholder="Account details (e.g., bank name)" className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"/>
                                <button type="submit" className="bg-blue-500 text-white font-semibold py-2 px-3 rounded-lg hover:bg-blue-600 text-sm">Add</button>
                             </form>
                        </div>
                    </div>
                )}
                
                {activeTab === 'users' && (
                     <div>
                        <h4 className="text-lg font-semibold text-gray-700 mb-4">User Management</h4>
                         <button onClick={() => { setSelectedUser(null); setIsUserModalOpen(true); }} className="bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 text-sm mb-6">Add User</button>
                        <div className="overflow-x-auto">
                            <table className="min-w-full bg-white">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="py-3 px-4 text-left text-sm font-semibold text-gray-900">User</th>
                                        <th className="py-3 px-4 text-left text-sm font-semibold text-gray-900">Role</th>
                                        <th className="py-3 px-4 text-left text-sm font-semibold text-gray-900">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                    {users.map(user => (
                                        <tr key={user.id}>
                                            <td className="py-3 px-4 text-sm text-gray-700">{user.name}</td>
                                            <td className="py-3 px-4 text-sm text-gray-700">
                                                 <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${user.role === 'Admin' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                                    {user.role}
                                                 </span>
                                            </td>
                                            <td className="py-3 px-4 text-sm"><ActionButtons hideView onEdit={() => handleEditUser(user)} onDelete={() => handleDeleteUserLocal(user.id)} /></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {activeTab === 'integrations' && (
                    <div className="space-y-8">
                        <div>
                             <h4 className="text-lg font-semibold text-gray-700">Connect Your Tools</h4>
                            <p className="text-gray-600 mt-1">
                                Automate your workflows by connecting Samay PMS with your favorite apps.
                            </p>
                        </div>
                        
                        {integrationCategories.map(category => {
                            const filteredIntegrations = integrations.filter(int => int.category === category);
                            if(filteredIntegrations.length === 0) return null;

                            return (
                                <div key={category}>
                                    <h5 className="text-md font-semibold text-gray-700 mb-4 pb-2 border-b">{category}</h5>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {filteredIntegrations.map(integration => (
                                            <IntegrationCard
                                                key={integration.id}
                                                integration={integration}
                                                onManage={handleManageIntegration}
                                            />
                                        ))}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}

                {activeTab === 'security' && (
                    <div>
                        <h4 className="text-lg font-semibold text-gray-700 mb-2">Security & Audit Log</h4>
                        <p className="text-gray-600 mb-6">
                            Review a chronological log of all activities that have occurred in your system.
                        </p>
                        <div className="overflow-x-auto">
                            <table className="min-w-full bg-white">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Timestamp</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">User</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Action</th>
                                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Details</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                    {auditLogs.map((log) => {
                                        const actionChip = getActionChip(log.action);
                                        return (
                                            <tr key={log.id} className="hover:bg-gray-50">
                                                <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm sm:pl-6 text-gray-500">
                                                    {new Date(log.timestamp).toLocaleString()}
                                                </td>
                                                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900 font-medium">
                                                    {getUserName(log.userId)}
                                                </td>
                                                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <span className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ${actionChip.color}`}>
                                                        {actionChip.text}
                                                    </span>
                                                </td>
                                                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-700">
                                                    {log.details}
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>
             <IntegrationSettingsModal
                isOpen={isIntegrationModalOpen}
                onClose={() => setIsIntegrationModalOpen(false)}
                onSave={onSaveIntegration}
                integration={selectedIntegration}
             />
             <UserModal
                isOpen={isUserModalOpen}
                onClose={() => setIsUserModalOpen(false)}
                onSave={handleSaveUserModal}
                user={selectedUser}
             />
        </div>
    );
};