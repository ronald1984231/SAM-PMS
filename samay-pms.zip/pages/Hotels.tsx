
import React, { useState, useMemo } from 'react';
import { Property, Booking, PlatformSettings } from '../types';
import { HotelModal } from '../components/HotelModal';
import { ActionButtons } from '../components/ActionButtons';

interface HotelsProps {
    properties: Property[];
    bookings: Booking[];
    onSaveProperty: (property: Omit<Property, 'id' | 'customerId'> & { id?: string }) => void;
    onDeleteProperty: (propertyId: string) => void;
    platformSettings: PlatformSettings;
}

const calculateCurrentMonthRevenue = (propertyId: string, bookings: Booking[]): number => {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    return bookings
        .filter(b => {
            if (b.propertyId !== propertyId) return false;
            const checkInDate = new Date(b.checkIn);
            // Ensure booking is within the current month
            return checkInDate >= firstDayOfMonth && checkInDate <= lastDayOfMonth;
        })
        .reduce((total, b) => total + b.totalPrice, 0);
};

export const Hotels: React.FC<HotelsProps> = ({ properties, bookings, onSaveProperty, onDeleteProperty, platformSettings }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

    const currencyFormatter = useMemo(() => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: platformSettings.currency,
            minimumFractionDigits: 0,
        });
    }, [platformSettings.currency]);

    const handleOpenModal = (property: Property | null) => {
        setSelectedProperty(property);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedProperty(null);
    };

    const handleSave = (property: Omit<Property, 'id' | 'customerId'> & { id?: string }) => {
        onSaveProperty(property);
        handleCloseModal();
    };

    const handleDelete = (propertyId: string) => {
        if (window.confirm('Are you sure you want to delete this hotel? This action is permanent and will delete all associated data.')) {
            onDeleteProperty(propertyId);
        }
    };

    const propertiesWithRevenue = useMemo(() => {
        return properties.map(p => ({
            ...p,
            currentMonthRevenue: calculateCurrentMonthRevenue(p.id, bookings)
        }));
    }, [properties, bookings]);
    
    const ManagementTypeBadge: React.FC<{type: 'OYO' | 'SELF'}> = ({ type }) => {
        const isOyo = type === 'OYO';
        return (
            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${isOyo ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                {isOyo ? 'Oyo Managed' : 'Self Managed'}
            </span>
        );
    }

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-gray-800">Hotel Management</h3>
                <button onClick={() => handleOpenModal(null)} className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary font-semibold">
                    Add New Hotel
                </button>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Hotel Name</th>
                            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Location</th>
                            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Management Type</th>
                            <th scope="col" className="px-3 py-3.5 text-right text-sm font-semibold text-gray-900">Current Month Revenue</th>
                            <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6 text-left text-sm font-semibold text-gray-900">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {propertiesWithRevenue.map((property) => (
                            <tr key={property.id} className="hover:bg-gray-50">
                                <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">{property.name}</td>
                                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{property.location}</td>
                                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                    <ManagementTypeBadge type={property.managementType} />
                                </td>
                                <td className="whitespace-nowrap px-3 py-4 text-sm text-right text-gray-700 font-semibold">{currencyFormatter.format(property.currentMonthRevenue)}</td>
                                <td className="whitespace-nowrap py-4 pl-3 pr-4 text-left text-sm font-medium sm:pr-6">
                                    <ActionButtons 
                                        onView={() => handleOpenModal(property)}
                                        onEdit={() => handleOpenModal(property)}
                                        onDelete={() => handleDelete(property.id)}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {isModalOpen && (
                <HotelModal
                    isOpen={isModalOpen}
                    onClose={handleCloseModal}
                    onSave={handleSave}
                    property={selectedProperty}
                />
            )}
        </div>
    );
};