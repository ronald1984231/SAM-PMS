
import React, { useMemo, useState } from 'react';
import { Booking, Room, BookingStatus, Guest, RoomType, HousekeepingStatus } from '../types';
import { RoomModal } from '../components/RoomModal';
import { BulkAddRoomModal } from '../components/BulkAddRoomModal';
import { ActionButtons } from '../components/ActionButtons';


const housekeepingStatusConfig: { [key in HousekeepingStatus]: { color: string; text: string; } } = {
    [HousekeepingStatus.Clean]: { color: 'bg-green-500', text: 'Clean' },
    [HousekeepingStatus.Dirty]: { color: 'bg-yellow-500', text: 'Dirty' },
    [HousekeepingStatus.InProgress]: { color: 'bg-blue-500', text: 'In Progress' },
    [HousekeepingStatus.Inspection]: { color: 'bg-purple-500', text: 'Inspection' },
};

const occupancyStatusConfig = {
    'Stay Over': { color: 'bg-blue-600', text: 'Stay Over' },
    'Due Out': { color: 'bg-red-600', text: 'Due Out' },
    'Arrived': { color: 'bg-green-600', text: 'Arrived' },
    'Vacant': { color: 'bg-gray-400', text: 'Vacant' },
};


interface RoomCardProps {
    room: Room;
    occupancy: { status: keyof typeof occupancyStatusConfig; guestName?: string; dates?: string; };
    onEdit: () => void;
    onDelete: () => void;
}

const RoomCard: React.FC<RoomCardProps> = ({ room, occupancy, onEdit, onDelete }) => {
    const hkStatus = housekeepingStatusConfig[room.housekeepingStatus];
    const occStatus = occupancyStatusConfig[occupancy.status];
    const cardColor = room.housekeepingStatus === HousekeepingStatus.Dirty ? 'bg-red-50' : 'bg-green-50';

    return (
        <div className={`rounded-lg shadow p-4 flex flex-col justify-between border ${cardColor} border-gray-200`}>
            <div className="flex justify-between items-start mb-2">
                <h4 className="font-bold text-lg text-gray-800">{room.name}</h4>
                 <div className={`px-2 py-0.5 text-xs font-semibold text-white rounded ${hkStatus.color}`}>
                    {hkStatus.text}
                </div>
            </div>
            <div className="text-center my-2 flex-grow">
                <p className="font-semibold text-gray-700 truncate">{occupancy.guestName || room.type}</p>
                <p className="text-xs text-gray-500">{occupancy.dates || 'Available'}</p>
            </div>
            <div className="flex justify-between items-center mt-2">
                <div className={`px-2 py-1 text-xs text-center font-semibold text-white rounded-full ${occStatus.color}`}>
                    {occStatus.text}
                </div>
                <ActionButtons onEdit={onEdit} onDelete={onDelete} hideView />
            </div>
        </div>
    );
};


interface RoomManagementProps {
    rooms: Room[];
    bookings: Booking[];
    guests: Guest[];
    onSaveRoom: (room: Omit<Room, 'id' | 'propertyId' | 'housekeepingStatus'> & { id?: string }) => void;
    onDeleteRoom: (roomId: string) => void;
    onBulkSaveRooms: (prefix: string, start: number, end: number, type: RoomType) => void;
}

export const RoomManagement: React.FC<RoomManagementProps> = ({ rooms, bookings, guests, onSaveRoom, onDeleteRoom, onBulkSaveRooms }) => {
    
    const [roomTypeFilter, setRoomTypeFilter] = useState<RoomType | 'ALL'>('ALL');
    const [roomStatusFilter, setRoomStatusFilter] = useState<'ALL' | 'Occupied' | 'Vacant'>('ALL');
    const [isRoomModalOpen, setIsRoomModalOpen] = useState(false);
    const [isBulkAddModalOpen, setIsBulkAddModalOpen] = useState(false);
    const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

    const todayStr = new Date().toISOString().split('T')[0];

    const roomStatusMap = useMemo(() => {
        const map = new Map<string, { status: keyof typeof occupancyStatusConfig; guestName?: string; dates?: string; }>();
        rooms.forEach(room => {
            const checkedInBooking = bookings.find(b => b.roomId === room.id && b.status === BookingStatus.CheckedIn);
            const arrivingBooking = bookings.find(b => b.roomId === room.id && b.checkIn === todayStr && b.status === BookingStatus.Confirmed);

            if (checkedInBooking) {
                const guest = guests.find(g => g.id === checkedInBooking.guestId);
                const isDeparting = checkedInBooking.checkOut === todayStr;
                map.set(room.id, {
                    status: isDeparting ? 'Due Out' : 'Stay Over',
                    guestName: guest?.name,
                    dates: `${checkedInBooking.checkIn} to ${checkedInBooking.checkOut}`
                });
            } else if (arrivingBooking) {
                const guest = guests.find(g => g.id === arrivingBooking.guestId);
                 map.set(room.id, { status: 'Arrived', guestName: guest?.name, dates: `Arriving Today` });
            } else {
                map.set(room.id, { status: 'Vacant' });
            }
        });
        return map;
    }, [rooms, bookings, guests, todayStr]);

    const filteredRooms = useMemo(() => {
        return rooms.filter(room => {
            if (roomTypeFilter !== 'ALL' && room.type !== roomTypeFilter) {
                return false;
            }
            if (roomStatusFilter !== 'ALL') {
                 const status = roomStatusMap.get(room.id)?.status;
                 if (roomStatusFilter === 'Occupied' && status === 'Vacant') return false;
                 if (roomStatusFilter === 'Vacant' && status !== 'Vacant') return false;
            }
            return true;
        })
    }, [rooms, roomTypeFilter, roomStatusFilter, roomStatusMap]);

    const handleOpenRoomModal = (room: Room | null) => {
        setSelectedRoom(room);
        setIsRoomModalOpen(true);
    };

    const handleCloseRoomModal = () => {
        setIsRoomModalOpen(false);
        setSelectedRoom(null);
    };

    const handleSaveAndClose = (room: Omit<Room, 'id' | 'propertyId' | 'housekeepingStatus'> & { id?: string }) => {
        onSaveRoom(room);
        handleCloseRoomModal();
    };
    
    const handleSaveBulkAndClose = (prefix: string, start: number, end: number, type: RoomType) => {
        onBulkSaveRooms(prefix, start, end, type);
        setIsBulkAddModalOpen(false);
    };

    const handleDeleteAndClose = (roomId: string) => {
        onDeleteRoom(roomId);
        handleCloseRoomModal();
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex flex-wrap justify-between items-center gap-2 mb-4">
                <h3 className="text-xl font-semibold text-gray-800">Rooms Overview</h3>
                 <div className="flex space-x-2">
                     <button onClick={() => setIsBulkAddModalOpen(true)} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-brand-dark font-semibold">
                        Bulk Add Rooms
                    </button>
                    <button onClick={() => handleOpenRoomModal(null)} className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary font-semibold">
                        Add New Room
                    </button>
                 </div>
            </div>
            <div className="flex flex-wrap items-center gap-4 mb-4">
                {/* Room Type Filter */}
                <div className="flex items-center space-x-2 bg-gray-100 p-1 rounded-lg">
                    <button onClick={() => setRoomTypeFilter('ALL')} className={`px-3 py-1 text-sm font-semibold rounded-md ${roomTypeFilter === 'ALL' ? 'bg-white shadow' : 'text-gray-600'}`}>All</button>
                    {Object.values(RoomType).map(type => (
                         <button key={type} onClick={() => setRoomTypeFilter(type)} className={`px-3 py-1 text-sm font-semibold rounded-md ${roomTypeFilter === type ? 'bg-white shadow' : 'text-gray-600'}`}>{type}</button>
                    ))}
                </div>
                 {/* Occupancy Status Filter */}
                 <div className="flex items-center space-x-2 bg-gray-100 p-1 rounded-lg">
                     <button onClick={() => setRoomStatusFilter('ALL')} className={`px-3 py-1 text-sm font-semibold rounded-md ${roomStatusFilter === 'ALL' ? 'bg-white shadow' : 'text-gray-600'}`}>All</button>
                     <button onClick={() => setRoomStatusFilter('Occupied')} className={`px-3 py-1 text-sm font-semibold rounded-md ${roomStatusFilter === 'Occupied' ? 'bg-white shadow' : 'text-gray-600'}`}>Occupied</button>
                     <button onClick={() => setRoomStatusFilter('Vacant')} className={`px-3 py-1 text-sm font-semibold rounded-md ${roomStatusFilter === 'Vacant' ? 'bg-white shadow' : 'text-gray-600'}`}>Vacant</button>
                 </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
                {filteredRooms.map(room => (
                    <RoomCard
                        key={room.id}
                        room={room}
                        occupancy={roomStatusMap.get(room.id)!}
                        onEdit={() => handleOpenRoomModal(room)}
                        onDelete={() => handleDeleteAndClose(room.id)}
                    />
                ))}
            </div>

            {isRoomModalOpen && (
                <RoomModal
                    isOpen={isRoomModalOpen}
                    onClose={handleCloseRoomModal}
                    onSave={handleSaveAndClose}
                    onDelete={handleDeleteAndClose}
                    room={selectedRoom}
                />
            )}
            
            {isBulkAddModalOpen && (
                <BulkAddRoomModal
                    isOpen={isBulkAddModalOpen}
                    onClose={() => setIsBulkAddModalOpen(false)}
                    onSave={handleSaveBulkAndClose}
                />
            )}
        </div>
    );
};