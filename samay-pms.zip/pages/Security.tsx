
import React from 'react';
import { AuditLog, User } from '../types';

const getActionChip = (action: string): { text: string; color: string } => {
    switch (action) {
        case 'LOGIN':
            return { text: 'Login', color: 'bg-green-100 text-green-800' };
        case 'LOGIN_FAILED':
            return { text: 'Login Failed', color: 'bg-red-100 text-red-800' };
        case 'UPDATE_BOOKING':
        case 'CREATE_BOOKING':
            return { text: 'Booking', color: 'bg-blue-100 text-blue-800' };
        case 'UPDATE_HOUSEKEEPING':
            return { text: 'Housekeeping', color: 'bg-yellow-100 text-yellow-800' };
        case 'TOGGLE_INTEGRATION':
            return { text: 'Integration', color: 'bg-purple-100 text-purple-800' };
        default:
            return { text: 'System', color: 'bg-gray-100 text-gray-800' };
    }
};

interface SecurityProps {
    auditLogs: AuditLog[];
    users: User[];
}

export const Security: React.FC<SecurityProps> = ({ auditLogs, users }) => {

    const getUserName = (userId: string) => {
        return users.find(u => u.id === userId)?.name || 'System';
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Security & Audit Log</h3>
            <p className="text-gray-600 mb-6">
                Review a chronological log of all activities that have occurred in your system.
            </p>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Timestamp</th>
                            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">User</th>
                            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Action</th>
                            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Details</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {auditLogs.map((log) => {
                            const actionChip = getActionChip(log.action);
                            return (
                                <tr key={log.id} className="hover:bg-gray-50">
                                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm sm:pl-6 text-gray-500">
                                        {new Date(log.timestamp).toLocaleString()}
                                    </td>
                                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900 font-medium">
                                        {getUserName(log.userId)}
                                    </td>
                                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                        <span className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ${actionChip.color}`}>
                                            {actionChip.text}
                                        </span>
                                    </td>
                                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-700">
                                        {log.details}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
