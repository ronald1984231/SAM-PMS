
import React, { useState } from 'react';
import { Booking, PaymentMode, PaymentAccount, PlatformSettings } from '../types';
import { ReportDateFilter, DateRange } from '../components/reports/common/ReportDateFilter';
import { DayWiseSalesReport } from '../components/reports/DayWiseSalesReport';
import { MonthWiseSalesReport } from '../components/reports/MonthWiseSalesReport';
import { PaymentAccountReport } from '../components/reports/PaymentAccountReport';
import { PaymentModeReport } from '../components/reports/PaymentModeReport';

type ReportView = 'menu' | 'day_wise' | 'month_wise' | 'payment_account' | 'payment_mode';

interface ReportsProps {
    bookings: Booking[];
    paymentModes: PaymentMode[];
    paymentAccounts: PaymentAccount[];
    platformSettings: PlatformSettings;
}

const ReportCard: React.FC<{ title: string, description: string, onClick: () => void }> = ({ title, description, onClick }) => (
    <div onClick={onClick} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer border border-transparent hover:border-brand-primary">
        <h4 className="text-lg font-bold text-gray-800">{title}</h4>
        <p className="text-sm text-gray-600 mt-2">{description}</p>
    </div>
)

export const Reports: React.FC<ReportsProps> = ({ bookings, paymentModes, paymentAccounts, platformSettings }) => {
    const [view, setView] = useState<ReportView>('menu');
    const [dateRange, setDateRange] = useState<DateRange | null>(null);

    const reportItems = [
        { id: 'day_wise', title: 'Day wise Sales', description: 'View total sales for each day in a given period.' },
        { id: 'month_wise', title: 'Month Wise Sales', description: 'Aggregated sales data for each month.' },
        { id: 'payment_account', title: 'Payment Account Report', description: 'Breakdown of revenue by payment account.' },
        { id: 'payment_mode', title: 'Payment Mode Report', description: 'Analyze revenue based on different payment modes.' },
    ];

    const renderReport = () => {
        if (view === 'menu') {
            return (
                 <div className="space-y-8">
                    <div>
                        <h3 className="text-xl font-semibold text-gray-700 mb-4 pb-2 border-b">Available Reports</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {reportItems.map(report => (
                                <ReportCard key={report.id} {...report} onClick={() => setView(report.id as ReportView)} />
                            ))}
                        </div>
                    </div>
                </div>
            );
        }

        if (!dateRange) {
             return <p className="text-center text-gray-500">Loading report filters...</p>;
        }

        switch (view) {
            case 'day_wise':
                return <DayWiseSalesReport bookings={bookings} dateRange={dateRange} platformSettings={platformSettings} />;
            case 'month_wise':
                return <MonthWiseSalesReport bookings={bookings} dateRange={dateRange} platformSettings={platformSettings} />;
            case 'payment_account':
                return <PaymentAccountReport bookings={bookings} paymentAccounts={paymentAccounts} dateRange={dateRange} platformSettings={platformSettings} />;
            case 'payment_mode':
                return <PaymentModeReport bookings={bookings} paymentModes={paymentModes} dateRange={dateRange} platformSettings={platformSettings} />;
            default:
                return null;
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <h3 className="text-2xl font-semibold text-gray-800">Analytics & Reports</h3>
                {view !== 'menu' && (
                    <button onClick={() => setView('menu')} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-semibold">
                        &larr; Back to Menu
                    </button>
                )}
            </div>
            
            {view !== 'menu' && (
                <div className="bg-white p-4 rounded-xl shadow-md">
                   <ReportDateFilter onDateChange={setDateRange} />
                </div>
            )}

            <div className="bg-white p-6 rounded-xl shadow-sm">
                {renderReport()}
            </div>
        </div>
    );
};
