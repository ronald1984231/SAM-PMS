
import React, { useState, useMemo } from 'react';
import { Room, Booking, Guest, BookingStatus, PaymentMode, PaymentAccount, RoomType, PlatformSettings, Property } from '../types';
import { BookingModal } from '../components/BookingModal';

const statusColors: { [key in BookingStatus]: string } = {
    [BookingStatus.Confirmed]: 'bg-status-confirmed',
    [BookingStatus.CheckedIn]: 'bg-status-checked-in',
    [BookingStatus.CheckedOut]: 'bg-status-checked-out',
    [BookingStatus.Cancelled]: 'bg-gray-400',
};

const BookingBlock: React.FC<{ booking: Booking, guestName: string, days: number, offset: number, onClick: () => void }> = ({ booking, guestName, days, offset, onClick }) => {
    return (
        <div 
            className={`absolute h-12 top-2 rounded-lg shadow-sm flex items-center px-3 text-white overflow-hidden transition-all duration-300 hover:opacity-100 opacity-90 cursor-pointer ${statusColors[booking.status]}`}
            style={{
                left: `calc(${offset * 100}% + 2px)`,
                width: `calc(${days * 100}% - 4px)`,
            }}
            title={`Guest: ${guestName}\nStatus: ${booking.status.replace('_', ' ')}\nCheck-in: ${booking.checkIn}\nCheck-out: ${booking.checkOut}`}
            onClick={onClick}
        >
            <div className="flex flex-col justify-center w-full">
                <p className="font-bold text-sm truncate">{guestName}</p>
                <p className="text-xs truncate">{booking.status.replace('_', ' ')}</p>
            </div>
        </div>
    );
};

interface CalendarProps {
    rooms: Room[];
    bookings: Booking[];
    guests: Guest[];
    onSaveBooking: (booking: Omit<Booking, 'id'> & { id?: string }) => void;
    propertyId: string;
    paymentModes: PaymentMode[];
    paymentAccounts: PaymentAccount[];
    platformSettings: PlatformSettings;
    selectedProperty: Property;
}

export const Calendar: React.FC<CalendarProps> = ({ rooms, bookings, guests, onSaveBooking, propertyId, paymentModes, paymentAccounts, platformSettings, selectedProperty }) => {
    const [startDate, setStartDate] = useState(new Date());
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);

    const daysToShow = 14;
    const dateHeaders = Array.from({ length: daysToShow }, (_, i) => {
        const date = new Date(startDate);
        date.setDate(startDate.getDate() + i);
        return date;
    });

    const roomTypes = Object.values(RoomType);
    const roomsByType = useMemo(() => {
        const map = new Map<RoomType, Room[]>();
        roomTypes.forEach(type => map.set(type, rooms.filter(r => r.type === type)));
        return map;
    }, [rooms]);

    const bookingsMap = useMemo(() => {
        const map = new Map<string, { booking: Booking, guestName: string }[]>();
        bookings.forEach(booking => {
            const guest = guests.find(g => g.id === booking.guestId);
            if (!guest) return;
            const roomBookings = map.get(booking.roomId) || [];
            roomBookings.push({ booking, guestName: guest.name });
            map.set(booking.roomId, roomBookings);
        });
        return map;
    }, [bookings, guests]);

    const dailyStats = useMemo(() => {
        return dateHeaders.map(date => {
            const dateTimestamp = new Date(date).setHours(0,0,0,0);
            const occupiedRooms = bookings.filter(b => {
                const checkIn = new Date(b.checkIn).setHours(0,0,0,0);
                const checkOut = new Date(b.checkOut).setHours(0,0,0,0);
                return dateTimestamp >= checkIn && dateTimestamp < checkOut && b.status !== BookingStatus.Cancelled;
            }).length;
            const occupancy = rooms.length > 0 ? Math.round((occupiedRooms / rooms.length) * 100) : 0;
            return { occupiedRooms, occupancy };
        });
    }, [dateHeaders, bookings, rooms]);

    const changeDate = (days: number) => {
        setStartDate(prev => {
            const newDate = new Date(prev);
            newDate.setDate(prev.getDate() + days);
            return newDate;
        });
    };

    const handleEditBooking = (booking: Booking) => {
        setSelectedBooking(booking);
        setIsModalOpen(true);
    };

    const handleSave = (bookingToSave: Omit<Booking, 'id'> & { id?: string }) => {
        onSaveBooking(bookingToSave);
        setIsModalOpen(false);
    };
    
    const today = new Date().toISOString().split('T')[0];

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-gray-800">Rooms Availability</h3>
                <div className="flex items-center space-x-2">
                    <button onClick={() => changeDate(-7)} className="px-3 py-1 bg-gray-200 rounded-md hover:bg-gray-300">&laquo; Prev</button>
                    <button onClick={() => setStartDate(new Date())} className="px-3 py-1 bg-gray-300 rounded-md hover:bg-gray-400">Today</button>
                    <button onClick={() => changeDate(7)} className="px-3 py-1 bg-gray-200 rounded-md hover:bg-gray-300">Next &raquo;</button>
                </div>
            </div>

            <div className="overflow-x-auto">
                <div className="grid gap-px bg-gray-200 border-l border-t border-gray-200" style={{ gridTemplateColumns: `150px repeat(${daysToShow}, minmax(100px, 1fr))` }}>
                    {/* Header: Room Name */}
                    <div className="bg-gray-100 p-3 font-semibold text-gray-600 sticky left-0 z-20">Room</div>
                    {/* Header: Dates */}
                    {dateHeaders.map(date => {
                        const dateStr = date.toISOString().split('T')[0];
                        const isToday = dateStr === today;
                        return (
                            <div key={date.toISOString()} className={`p-3 text-center ${isToday ? 'bg-brand-light font-bold text-brand-primary' : 'bg-gray-100'}`}>
                                <div className="text-sm font-medium">{date.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                                <div className="text-lg">{date.getDate()}</div>
                            </div>
                        );
                    })}

                    {/* Body: Rooms and Bookings */}
                    {roomTypes.map(type => (
                        <React.Fragment key={type}>
                            {/* Room Type Header */}
                            <div className="col-span-full bg-gray-200 p-2 font-bold text-gray-700 sticky left-0 z-10">{type} ROOM</div>

                            {(roomsByType.get(type) || []).map(room => (
                                <React.Fragment key={room.id}>
                                    <div className="bg-white p-3 font-semibold sticky left-0 z-10 flex items-center border-b border-r border-gray-200">
                                        {room.name}
                                    </div>
                                    <div className="col-span-14 bg-gray-50 relative grid border-b border-gray-200 h-16" style={{ gridTemplateColumns: `repeat(${daysToShow}, 1fr)`}}>
                                        {bookingsMap.get(room.id)?.map(({ booking, guestName }) => {
                                            const bookingStart = new Date(booking.checkIn);
                                            const bookingEnd = new Date(booking.checkOut);
                                            const gridStart = new Date(dateHeaders[0].toISOString().split('T')[0]);
                                            const gridEnd = new Date(dateHeaders[daysToShow-1].toISOString().split('T')[0]);

                                            if (bookingEnd <= gridStart || bookingStart > gridEnd) return null;

                                            const start = Math.max(bookingStart.getTime(), gridStart.getTime());
                                            const end = Math.min(bookingEnd.getTime(), new Date(gridEnd).setDate(gridEnd.getDate() + 1));

                                            const offset = Math.round((start - gridStart.getTime()) / (1000 * 3600 * 24));
                                            const days = Math.round((end - start) / (1000 * 3600 * 24));

                                            if(days <= 0) return null;

                                            return <BookingBlock key={booking.id} booking={booking} guestName={guestName} days={days} offset={offset} onClick={() => handleEditBooking(booking)} />;
                                        })}
                                    </div>
                                </React.Fragment>
                            ))}
                        </React.Fragment>
                    ))}
                    {/* Footer: Occupancy */}
                    <div className="bg-gray-100 p-3 font-semibold text-gray-600 sticky left-0 z-20">Occupancy</div>
                    {dailyStats.map((stat, i) => (
                        <div key={i} className="bg-gray-100 p-3 text-center font-bold text-sm text-gray-700">
                            {stat.occupancy}%
                        </div>
                    ))}
                </div>
            </div>
            {isModalOpen && (
                 <BookingModal
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    onSave={handleSave}
                    booking={selectedBooking}
                    rooms={rooms}
                    guests={guests}
                    existingBookings={bookings}
                    propertyId={propertyId}
                    paymentModes={paymentModes}
                    paymentAccounts={paymentAccounts}
                    platformSettings={platformSettings}
                    propertyManagementType={selectedProperty.managementType}
                />
            )}
        </div>
    );
};